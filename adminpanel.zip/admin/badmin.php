<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewResponsiveport" content="width=device-width, initial-scale=1.0" />
    <title>Block/Unblock Admin </title>
<?php
	include('header.php');
?>
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Block/Unblock Admin</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
    <div class="panel-heading">  
    </div>
    <div class="panel-body">
  
		<?php
			$sql="select * from tbladminreg";
			include('dbcon.php');
			$result=mysqli_query($con,$sql);
			$count=mysqli_num_rows($result);
			if($count==0)
			{
				echo "<h4 style=\"color:red\">No Record Found</h4>";
			}
			else
			{	echo "<h4 style=\"color:green\">Total $count Records Found</h4>";
				 echo "<table class=\"table\">
						<tr>
							<th>ACTION</th>
							<th>ID</th>
							<th>NAME</th>
							<th>USERNAME</th>
							<th>MOBILENO</th>
							<th>PHOTO</th>
							<th>STATUS</th>
							<th>REGDATE</th>
						</tr>";
	 
					while($line=mysqli_fetch_array($result))
					{
						$id=$line['adminid'];
						echo "<tr>";
						echo "<td>
						<a href=\"unblockadmin.php?id=$id\"><img src=\"unblock.jpg\" type=\"submit\" class=\"btn\" value=\"EDIT\"/></a><br>
						<a href=\"blockadmin.php?id=$id\"><img src=\"block.jpg\"  class=\"btn\" value=\"DELETE\"/></a>";
						echo "</td><td>";
						echo $line['adminid'];
						echo "</td><td>";
						echo $line['fullname'];
						echo "</td><td>";
						echo $line['username'];
						echo "</td><td>";
						echo $line['mobileno'];
						echo "</td><td><img style=\"height:100px;width:120px;\" src=\"";
						echo $line['photo'];
						echo "\" /></td><td>";
						echo $line['status'];
						echo "</td><td>";
						echo $line['cdate'];
						echo "</td>";
						echo "</tr>";
						
					}
			
						echo "</table>";
			}
		?>
 
     </div>
                    </div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
<?php
	include('footer.php');
?>