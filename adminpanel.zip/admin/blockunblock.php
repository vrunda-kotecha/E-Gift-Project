<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Project Admin</title>
		<?php
			include ('header.php');
		?>
		<style>
			
			.img1
			{
				
				border-radius:50%;
				padding:10px; 
				width:300px;
				height:270px;
			} 
			
			.col-md-4
			{
				height:270px;
				widht:270px;
			}
		</style>
		</head>
		
        <div id="page-wrapper" >
            <div id="page-inner" >
                <div class="row" >
                    <div class="col-md-12">
                        <h3 style="color:black">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>
						</h3>
						</div>
						<div class="row">
							<div class="col-md-4">
								<a href="badmin.php"><img src="add.jpg" type="submit" class="img1" value="CREATE"/></a><br>
							</div>
							<div class="col-md-4">
								<a href="bbuyer.php"><img src="buyer1.jpg" type="submit" class="img1" value="CREATE"/></a><br>
							</div>
							
						</div>
						
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
