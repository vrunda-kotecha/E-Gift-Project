<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Create New Recipient</title>
		<?php
			include ('header.php');
		?>
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Create New Recipient</h1>
                       <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
							<div class="panel-heading">
								<?php
									if (isset ($_POST['btnsubmit']))
									{
										if (empty ($_POST ['txtbrandname']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Recipient Name</h3>";										
											}
										
										else
										{
											$bn=$_POST['txtbrandname']; 
											$s=1;
											$timeZone = new DateTimeZone("Asia/Kolkata");
											  $date = new DateTime();
											  $date->setTimeZone($timeZone);
											  $d = $date->format('y-m-d h:i:s');
											
											include ('dbcon.php');
											$sql="insert into tblbrand values(NULL,'$bn','$s','$d')";
														if (mysqli_query($con,$sql))
														{
															echo "<h3 style=\"color:green;\">New Recipient Registered</h3>";
														}
														else
														{
															echo "<h3 style=\"color:red;\">ERROR</h3>";
														}
										}
											
									}
								?>
							</div>
						<div class="panel-body">
							<form id="form1" name="form1" enctype="multipart/form-data" method="POST" action="">
								<div class="form-group">
									<label>Enter Recipient Name</label>
									<input id="txtbrandname" name="txtbrandname" class="form-control" type="text" value="<?php if(isset($_POST['txtbrandname'])) echo $_POST['txtbrandname']; ?>"/>
								</div>
								
									<input id="btnsubmit" name="btnsubmit" type="submit" class="btn" value="SUBMIT"/>
							</form>
						</div>
						
						
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
