﻿<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewResponsiveport" content="width=device-width, initial-scale=1.0" />
    <title> Create New Category</title>
<?php
	include('header.php');
?>
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Create New Category</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>
							</h3>
     <div class="panel-heading">
<?php
	if(isset($_POST['btnsubmit']))
	{
		if(empty($_POST['txtcname']))
		{			
		  echo "<h3 style=\"color:red;\">Please Enter Category</h3>";
		}
		else
		{
			$cn=$_POST['txtcname'];
			$ph="google.jpg";
			$s=1;
			$timeZone = new DateTimeZone("Asia/Kolkata");
			$date = new DateTime();
			$date->setTimeZone($timeZone);
			$d = $date->format('y-m-d h:i:s');
			
			include('dbcon.php');
			
			$path="1";
											
			$path="../image/".$_FILES['file']['name'];
			if(file_exists("../image/".$_FILES['file']['name']))
			{
				echo"<p style=\"color:red; text-align:center; font-weight:bold\">File is not selected or Name Already Exits Please Rename the File and Try Again.</p>";
			}
			else
			{
				$allowed=array('gif','png','jpg','jpeg','JPG','PNG','GIF','JPEG');
				$filename=$_FILES['file']['name'];
				$ext=pathinfo($filename,PATHINFO_EXTENSION);
				if(!in_array($ext,$allowed))
				{
					 echo"<p style=\"color:red; text-align:center; font-weight:bold;\">Not Compatible Format.Please Upload Only Image File.</p>";
				}
					else
				{
					move_uploaded_file($_FILES['file']['tmp_name'],"../image/".$_FILES['file']['name']);  	
			
					$sql="insert into tblitemcategory values(NULL,'$cn','$path','$s','$d')";
					
					if(mysqli_query($con,$sql))
					{				
						echo "<h1 style=\"color:green;\">New Category is Created Successfully</h1>";				
					}
					else
					{
						echo "<h1 style=\"color:red;\">error</h1>";
					}
				}	
				
			}
		}
	}					
?>
                        </div>
						<div class="panel-body">
  <form id="form1" name="form1" enctype="multipart/form-data" method="POST" action="">
   <div class="form-group">
		<label>Enter Category</label>
		<input id="txtcname" name="txtcname" class="form-control" type="text" value="" />
   </div>  
<div class="form-group">
	<label>Enter Photo</label>
	<input id="file" name="file" class="form-control" type="file" value="<?php if(isset($_POST['file'])) echo $_POST['file']; ?>"/>
</div>   
   <input type="submit" id="btnsubmit" name="btnsubmit" class="btn btn-info" value="SUBMIT" />

</form>
                            </div>
                    </div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
<?php
	include('footer.php');
?>
   