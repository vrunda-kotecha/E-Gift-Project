<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Add New Gift</title>
		<?php
			include ('header.php');
		?>
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Add New Gift</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>
							</h3>
							<div class="panel-heading">
								<?php
									if (isset ($_POST['btnsubmit']))
									{
										if (empty ($_POST ['txtgiftname']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Gift Name</h3>";										}
										else if (empty ($_POST ['txtcategoryid']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Category Id</h3>";
										}
										else if (empty($_POST['txtbrandid']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Brand Id</h3>";
										}
										else if (empty($_POST ['txtdescription']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Description</h3>";
										}
										else if (empty($_POST['txtheight']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Height of the Gift</h3>";
										}
										else if (empty($_POST['txtwidth']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Width of the Gift</h3>";
										}
										else if (empty($_POST['txtprice']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Price</h3>";
										}
										else if (empty($_POST['txtquantity']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Quantity Required</h3>";
										}
										else
										{
											$gn=$_POST['txtgiftname']; 
											$cid=$_POST['txtcategoryid'];
											$bid=$_POST['txtbrandid'];
											$des=$_POST['txtdescription'];
											$ph="google.jpg";
											$h=$_POST['txtheight'];
											$w=$_POST['txtwidth'];
											$pr=$_POST['txtprice'];
											$qnt=$_POST['txtquantity'];
											$s=1;
											$timeZone = new DateTimeZone("Asia/Kolkata");
											  $date = new DateTime();
											  $date->setTimeZone($timeZone);
											  $d = $date->format('y-m-d h:i:s');
											
											include ('dbcon.php');
											
											$path="1";
											
											$path="../image/".$_FILES['file']['name'];
											if(file_exists("../image/".$_FILES['file']['name']))
											{
												echo"<p style=\"color:red; text-align:center; font-weight:bold\">File is not selected or Name Already Exits Please Rename the File and Try Again.</p>";
											}
											else
											{
												$allowed=array('gif','png','jpg','jpeg','JPG','PNG','GIF','JPEG');
												  $filename=$_FILES['file']['name'];
												  $ext=pathinfo($filename,PATHINFO_EXTENSION);
												  if(!in_array($ext,$allowed))
												  {
													  echo"<p style=\"color:red; text-align:center; font-weight:bold;\">Not Compatible Format.Please Upload Only Image File.</p>";
												  }
												  else
												  {
													move_uploaded_file($_FILES['file']['tmp_name'],"../image/".$_FILES['file']['name']);  
												

													$sql="insert into tblgift values(NULL,'$gn','$cid','$bid','$des','$path','$h','$w','$pr','$qnt','$s','$d')";
													if (mysqli_query($con,$sql))
													{
														echo "<h3 style=\"color:green;\">New Gift Added Sucessfully</h3>";
													}
													else
													{
														echo "<h3 style=\"color:red;\">ERROR</h3>";
													}
													}	
											}
										}
									}
								?>
							</div>
						<div class="panel-body">
							<form id="form1" name="form1" enctype="multipart/form-data" method="POST" action="">
								<div class="form-group">
									<label>Enter Gift Name</label>
									<input id="txtgiftname" name="txtgiftname" class="form-control" type="text" value="<?php if(isset($_POST['txtgiftname'])) echo $_POST['txtgiftname']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Category Id</label>
									<input id="txtcategoryid" name="txtcategoryid" class="form-control" type="text" value="<?php if(isset($_POST['txtcategoryid'])) echo $_POST['txtcategoryid']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Brand Id</label>
									<input id="txtbrandid" name="txtbrandid" class="form-control" type="text" value="<?php if(isset($_POST['txtbrandid'])) echo $_POST['txtbrandid']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Gift Description</label>
									<input id="txtdescription" name="txtdescription" class="form-control" type="text" value="<?php if(isset($_POST['txtdescription'])) echo $_POST['txtdescription']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Gift Photo</label>
									<input id="file" name="file" class="form-control" type="file" value="<?php if(isset($_POST['file'])) echo $_POST['file']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Height of Gift</label>
									<input id="txtheight" name="txtheight" class="form-control" type="text" value="<?php if(isset($_POST['txtheight'])) echo $_POST['txtheight']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Width of Gift</label>
									<input id="txtwidth" name="txtwidth" class="form-control" type="text" value="<?php if(isset($_POST['txtwidth'])) echo $_POST['txtwidth']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Price</label>
									<input id="txtprice" name="txtprice" class="form-control" type="text" value="<?php if(isset($_POST['txtprice'])) echo $_POST['txtprice']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Required Quantity</label>
									<input id="txtquantity" name="txtquantity" class="form-control" type="number" value="<?php if(isset($_POST['txtquantity'])) echo $_POST['txtquantity']; ?>"/>
								</div>
									<input id="btnsubmit" name="btnsubmit" type="submit" class="btn" value="SUBMIT"/>
							</form>
						</div>
						
						
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
