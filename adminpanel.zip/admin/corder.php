<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Create New Order</title>
		<?php
			include ('header.php');
		?>
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Create New Order</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>
							</h3>
							<div class="panel-heading">
								<?php
									if (isset ($_POST['btnsubmit']))
									{
										if (empty ($_POST ['txtproductid']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Product Id</h3>";										}
										else if (empty($_POST ['txtquantity']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Quantity Required</h3>";
										}
										else if (empty($_POST['txtprice']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Price</h3>";
										}
										else if (empty($_POST['txttotal']))
										{
											echo "<h3 style=\"color:red;\">Please Total</h3>";
										}
										else if (empty($_POST['txtdescription']))
										{
											echo "<h3 style=\"color:red;\">Please Enter Description</h3>";
										}
										else if (empty($_POST ['txtusername']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Username</h3>";
										}
										else if (empty($_POST['txtadd']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Address</h3>";
										}
										else if (empty($_POST['txtpin']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Pincode</h3>";
										}
										else if (empty($_POST['txtmobileno']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Mobile Number</h3>";
										}
										else
										{
											$pid=$_POST['txtproductid'];
											$qnt=$_POST['txtquantity'];	
											$pr=$_POST['txtprice'];
											$t=$_POST['txttotal'];
											$des=$_POST['txtdescription'];
											$un=$_POST['txtusername'];
											$add=$_POST['txtadd'];
											$pin=$_POST['txtpin'];
											$mo=$_POST['txtmobileno'];
											$s=1;
											$timeZone = new DateTimeZone("Asia/Kolkata");
											  $date = new DateTime();
											  $date->setTimeZone($timeZone);
											  $d = $date->format('y-m-d h:i:s');
											
											include ('dbcon.php');
											
											$sql="insert into tblorder values(NULL,'$pid','$qnt','$pr','$t','$des','$un','$add','$pin','$mo','$s','$d')";
											if (mysqli_query($con,$sql))
											{
												echo "<h3 style=\"color:green;\">New Order Created Sucessfully</h3>";
											}
											else
											{
												echo "<h3 style=\"color:red;\">ERROR</h3>";
											}
										}
									}
								?>
							</div>
						<div class="panel-body">
							<form id="form1" name="form1" method="POST" action="">
								<div class="form-group">
									<label>Enter Product Id</label>
									<input id="txtproductid" name="txtproductid" class="form-control" type="text" value="<?php if(isset($_POST['txtproductid'])) echo $_POST['txtproductid']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Required Quantity</label>
									<input id="txtquantity" name="txtquantity" class="form-control" type="number" value="<?php if(isset($_POST['txtquantity'])) echo $_POST['txtquantity']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Price</label>
									<input id="txtprice" name="txtprice" class="form-control" type="number" value="<?php if(isset($_POST['txtprice'])) echo $_POST['txtprice']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Total</label>
									<input id="txttotal" name="txttotal" class="form-control" type="number" value="<?php if(isset($_POST['txttotal'])) echo $_POST['txttotal']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Order Description</label>
									<input id="txtdescription" name="txtdescription" class="form-control" type="text" value="<?php if(isset($_POST['txtdescription'])) echo $_POST['txtdescription']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Username</label>
									<input id="txtusername" name="txtusername" class="form-control" type="text" value="<?php if(isset($_POST['txtusername'])) echo $_POST['txtusername']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Address</label>
									<input id="txtadd" name="txtadd" class="form-control" type="text" value="<?php if(isset($_POST['txtadd'])) echo $_POST['txtadd']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Pincode</label>
									<input id="txtpin" name="txtpin" class="form-control" type="text" value="<?php if(isset($_POST['txtpin'])) echo $_POST['txtpin']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Mobile number</label>
									<input id="txtmobileno" name="txtmobileno" class="form-control" type="number" value="<?php if(isset($_POST['txtmobileno'])) echo $_POST['txtmobileno']; ?>"/>
								</div>
									<input id="btnsubmit" name="btnsubmit" type="submit" class="btn" value="SUBMIT"/>
							</form>
						</div>
						
						
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
