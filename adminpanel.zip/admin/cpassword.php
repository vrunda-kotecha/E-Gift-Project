<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Project Admin</title>
		<?php
			include ('header.php');
		?>
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Change Password</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
							<div class="panel-heading">
								<?php
									if (isset($_POST['btnupdate']))
									{
										$un=$_POST['txtusername'];
										$opass=$_POST['txtopassword'];
										$npass=$_POST['txtnpassword'];
										$ncpass=$_POST['txtnconfirmpassword'];
									if(empty($un))
									{
										echo"<p style=\"color:red; text-align:center; \">Please Enter Username</p>";
									}
									else if(empty($opass))
									{
										echo"<p style=\"color:red; text-align:center; \">Please Enter Old Password</p>";
									}
									else if(empty($npass))
									{
										echo"<p style=\"color:red; text-align:center; \">Please Enter New Password</p>";
									}
									else if(empty($ncpass))
									{
										echo"<p style=\"color:red; text-align:center; \">Please Enter New Confirm Password</p>";
									}
									else if ($npass!=$ncpass)
									{
											echo "<h3 style=\"color:red;\">Password and Confirm Password are not the same</h3>";
									}
										else
										{
											include('dbcon.php');
											$sql="UPDATE tbladminreg SET password='$npass' where username ='$un' and password='$opass';";
											if(mysqli_query($con,$sql))
											{
												echo"<h4 style=\"color:green; text-align:center;\">New Password Changed Successfully!</h4>";
											  
												echo'<script>clearinputs();</script>';
											}								  
											else
											{
												echo"<h4 style=\"color:red; text-align:center;\">Error</h4>";
											}
										}
										}
								?>
							</div>
						<div class="panel-body">
							<form id="form1" name="form1" method="POST" action="">
								<div class="form-group">
									<label>Enter Username</label>
									<input id="txtusername" name="txtusername" class="form-control" type="text" value="<?php if(isset($_POST['txtusername'])) echo $_POST['txtusername'];?>"/>
								</div>
								<div class="form-group">
									<label>Enter Old Password</label>
									<input id="txtopassword" name="txtopassword" class="form-control" type="password" value="<?php if(isset($_POST['txtopassword'])) echo $_POST['txtopassword']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter New Password</label>
									<input id="txtnpassword" name="txtnpassword" class="form-control" type="password" value="<?php if(isset($_POST['txtpassword'])) echo $_POST['txtpassword']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Confirm New Password</label>
									<input id="txtnconfirmpassword" name="txtnconfirmpassword" class="form-control" type="password" value="<?php if(isset($_POST['txtconfirmpassword'])) echo $_POST['txtconfirmpassword']; ?>"/>
								</div>
									<input id="btnupdate" name="btnupdate" type="submit" class="btn" value="UPDATE"/>
							</form>
						</div>
						
						
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
