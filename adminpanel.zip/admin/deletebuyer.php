<?php
	 ob_start();
	 include('dbcon.php');
	 $id=$_REQUEST['id'];
	 $s="delete from tblbuyer where itemid='$id'";
	 if(mysqli_query($con,$s))
	 {
		 header("location:mbuyer.php",true);
	 }
?>