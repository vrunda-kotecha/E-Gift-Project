<?php
	 ob_start();
	 include('dbcon.php');
	 $id=$_REQUEST['id'];
	 $s="delete from tblseller where itemid='$id'";
	 if(mysqli_query($con,$s))
	 {
		 header("location:mseller.php",true);
	 }
?>