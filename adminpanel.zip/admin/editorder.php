<?php
ob_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewResponsiveport" content="width=device-width, initial-scale=1.0" />
    <title>Update Order </title>
<?php
	include('header.php');
?>
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Update Order</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
     <div class="panel-heading">
     </div>
                        <div class="panel-body">
  
                    <form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
		
					 
					 <!-- Edit code start-->
					 <?php
					  if (isset($_POST['btnupdate']))
                      {
						  $id=$_GET['id'];
						  $des=$_POST['des'];
						  $price=$_POST['price'];
						  $qnt=$_POST['Qunatity'];
						  $add=$_POST['address'];
						  $pin=$_POST['pin'];
						  if(empty($des))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Description</p>";
						  }
						  else if(empty($price))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Price</p>";
						  }
						   else if(empty($qnt))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Quantity</p>";
						  }
						  else if(empty($add))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Address</p>";
						  }
						  else if(empty($pin))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Pincode</p>";
						  }
						  else
						  {
							  include('dbcon.php');
							  $sql="UPDATE tblorder SET description='$des',price='$price',quantity='$qnt',address='$add',pincode='$pin' where orderid ='$id';";
                              if(mysqli_query($con,$sql))
                              {
								  echo"<h4 style=\"color:green; text-align:center;\">Record Update Successfully!</h4>";
								  
								  header("Location:morder.php");
								  echo'<script>clearinputs();</script>';
							  }								  
							  else
							  {
								  echo"<h4 style=\"color:red; text-align:center;\">Error</h4>";
							  }
						 }
					  }						  
					 ?>
					  <!-- Edit code End-->
					 
					 <form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
					 <table class="table table-striped table-success">
					 <?php
					    include('dbcon.php');
						$id=$_GET['id'];
	                    $sql="SELECT * FROM tblorder where orderid='$id' ";
						$result=mysqli_query($con,$sql);
						echo"<table class=\"table table-striped table-success\">";
                        while($line=mysqli_fetch_array($result))
                        {	$id=$line['orderid'];
							$prid=$line['productid'];
							$qnt=$line['quantity'];
							$price=$line['price'];
							$total=$line['total'];
							$des=$line['description'];
							$name=$line['username'];
							$add=$line['address'];
							$pin=$line['pincode'];
							$regdate=$line['cdate'];
							
							
							echo"<tr><td>id</td>";
			                echo"<td>";
			                echo $id;
			                echo"</td>";
			                echo"</tr>";

							echo"<tr><td>Product Id</td>";
			                echo"<td>";
			                echo $line['productid'];
			                echo"</td>";
			                echo"</tr>";

							echo"<tr><td>Qunatity</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"Qunatity\" name=\"Qunatity\" class=\"form-control\"  value=\"$qnt\"/>";
							echo"</td>";
							echo"</tr>";

							echo"<tr><td>Price</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"price\" name=\"price\" class=\"form-control\"  value=\"$price\"/>";
							echo"</td>";
							echo"</tr>";

							echo"<tr><td>Total</td>";
			                echo"<td>";
			                echo $line['total'];
			                echo"</td>";
			                echo"</tr>";

							echo"<tr><td>Description</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"des\" name=\"des\" class=\"form-control\"  value=\"$des\"/>";
							echo"</td>";
							echo"</tr>";

							echo"<tr><td>Username</td>";
			                echo"<td>";
			                echo $line['username'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Address</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"address\" name=\"address\" class=\"form-control\"  value=\"$add\"/>";
							echo"</td>";
							echo"</tr>";
							
							echo"<tr><td>Pincode</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"pin\" name=\"pin\" class=\"form-control\"  value=\"$pin\"/>";
							echo"</td>";
							echo"</tr>";
							
							echo"<tr><td>Regdate</td>";
			                echo"<td>";
			                echo $line['cdate'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Status</td>";
			                echo"<td>";
			                echo $line['status'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<td>";
							echo"<input type=\"submit\" id=\"btnupdate\" name=\"btnupdate\" value=\"Update\" class=\"btn btn-success\"/>";
							echo"</td>";
						 echo"</tr>";
						}
                        echo"</table>";
                       ?>			
					 
                    </div>
                </div>              
               </div>
            </div>     
           <!-- /. ROW  -->            
               
<?php
	include('footer.php');
?>
</body>
</html>