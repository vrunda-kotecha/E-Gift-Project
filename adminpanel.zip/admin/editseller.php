<?php
ob_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewResponsiveport" content="width=device-width, initial-scale=1.0" />
    <title>Update Seller</title>
<?php
	include('header.php');
?>
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Update Seller</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
     <div class="panel-heading">
     </div>
                        <div class="panel-body">
  
                    <form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
		
					 <!-- photoupdate(edit) code start-->
					 <?php
					  if (isset($_POST['photoupdate']))
                      {
						   $id=$_GET['id'];
						   $path="1";
						  
					          $path="../image/".$_FILES['file']['name'];
							  if(file_exists("../image/".$_FILES['file']['name']))
							  {
								  echo"<p style=\"color:red; text-align:center; font-weight:bold\">File is not selected or Name Already Exits Please Rename the File and Try Again.</p>";
							  }
							  else
							  {
								  $allowed=array('gif','png','jpg','jpeg','JPG','PNG','GIF','JPEG');
								  $filename=$_FILES['file']['name'];
								  $ext=pathinfo($filename,PATHINFO_EXTENSION);
								  if(!in_array($ext,$allowed))
								  {
									  echo"<p style=\"color:red; text-align:center; font-weight:bold;\">Not Compatible Format.Please Upload Only Image File.</p>";
								  }
								  
								  
								  else
								  {
									move_uploaded_file($_FILES['file']['tmp_name'],"../image/".$_FILES['file']['name']);  
								  
								   include('dbcon.php');
							        $sql="UPDATE tblseller SET photo='$path' where itemid ='$id';";
                                   if(mysqli_query($con,$sql))
								  {
									  echo"<h4 style=\"color:green; text-align:center;\">Record Update Successfully!</h4>";
									  header("Location: mseller.php");
                            	 }								  
								  else
								  {
									  echo"<h4 style=\"color:red; text-align:center;\">Error</h4>";
								  }
								  }
							   }
					  }
						 ?>
					 <!-- phtoupdate code End-->
					 
					 <!-- Edit code start-->
					 <?php
					  if (isset($_POST['btnupdate']))
                      {
						  $id=$_GET['id'];
						  $name=$_POST['name'];
						  $add=$_POST['address'];
						  $pin=$_POST['pin'];
						  if(empty($name))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Name</p>";
						  }
						  else if(empty($add))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Address</p>";
						  }
						  else if(empty($pin))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Pincode</p>";
						  }
						  else
						  {
							  include('dbcon.php');
							  $sql="UPDATE tblseller SET fullname='$name',address='$add',pincode='$pin' where itemid ='$id';";
                              if(mysqli_query($con,$sql))
                              {
								  echo"<h4 style=\"color:green; text-align:center;\">Record Update Successfully!</h4>";
								  
								  header("Location:mseller.php");
								  echo'<script>clearinputs();</script>';
							  }								  
							  else
							  {
								  echo"<h4 style=\"color:red; text-align:center;\">Error</h4>";
							  }
						 }
					  }						  
					 ?>
					  <!-- Edit code End-->
					 
					 <form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
					 <table class="table table-striped table-success">
					 <?php
					    include('dbcon.php');
						$id=$_GET['id'];
	                    $sql="SELECT * FROM tblseller where itemid='$id' ";
						$result=mysqli_query($con,$sql);
						echo"<table class=\"table table-striped table-success\">";
                        while($line=mysqli_fetch_array($result))
                        {	$id=$line['itemid'];
							$name=$line['fullname'];
							$photo=$line['photo'];
							$username=$line['username'];
							$gender=$line['gender'];
							$add=$line['address'];
							$pin=$line['pincode'];
							$regdate=$line['cdate'];
							
							echo"<tr>";
							echo"<tr><td colspan=\"2\">";
			                echo "<img src=\"$photo\" style=\"height:200px;width:300px;\"class=\"p\"  />";
							echo"</td>";
							echo"<td>";
							echo "Change Photo :  <input type=\"file\" name=\"file\" id=\"file\" class=\"file\" value=\"\">";
							echo "<input type=\"submit\" name=\"photoupdate\" id=\"photoupdate\" value=\"Update\"   class=\"btn btn-success photoupdate\">";
							echo"</td>";
							echo"</tr>";
							
							echo"<tr><td>id</td>";
			                echo"<td>";
			                echo $id;
			                echo"</td>";
			                echo"</tr>";

                            echo"<tr><td>Name</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"name\" name=\"name\" class=\"form-control\" value=\"$name\" />";
							echo"</td>";
							echo"</tr>";
							
							echo"<tr><td>Username</td>";
			                echo"<td>";
			                echo $line['username'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Gender</td>";
			                echo"<td>";
			                echo $line['gender'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Birthdate</td>";
			                echo"<td>";
			                echo $line['birthdate'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Address</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"address\" name=\"address\" class=\"form-control\"  value=\"$add\"/>";
							echo"</td>";
							echo"</tr>";
							
							echo"<tr><td>Pincode</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"pin\" name=\"pin\" class=\"form-control\"  value=\"$pin\"/>";
							echo"</td>";
							echo"</tr>";
							
							echo"<tr><td>Regdate</td>";
			                echo"<td>";
			                echo $line['cdate'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Status</td>";
			                echo"<td>";
			                echo $line['status'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<td>";
							echo"<input type=\"submit\" id=\"btnupdate\" name=\"btnupdate\" value=\"Update\" class=\"btn btn-success\"/>";
							echo"</td>";
						 echo"</tr>";
						}
                        echo"</table>";
                       ?>			
					 
                    </div>
                </div>              
               </div>
            </div>     
           <!-- /. ROW  -->            
               
<?php
	include('footer.php');
?>
</body>
</html>