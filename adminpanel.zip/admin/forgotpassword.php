<?php
	ob_start();
?>
<html>
	<head>
		<title>Forgot Password Page</title>
		<style>
			body
			{
				background-image:Linear-Gradient(to bottom left,#4380B8,#00CA79);
			}
			.f1
			{
				background-color:white;
				height:300px;
				width:300px;
				margin-top:120px;
				margin-left:450px;
				padding:15px;
			}
			.f2
			{
				height:70px;
				margin-top:10px;
			}
			.h
			{
				font-size:15;
				font-family:Calibri;
				text-align:center;
				margin-top:5px;
			}
			.h1
			{
				float:left;
				font-family:Calibri;
				font-size:15;
			}
			.h3
			{
				font-family:Calibri;
				font-size:15;
				text-align:center;
				margin-top:10px
			}
			.title
			{
				font-family:Calibri;
				font-size:25;
				text-align:center;
			}
			#txtname
			{
				margin-top:5px;
				height:30px;
				width:280px;
				text-align:center;
			}
			#btnsubmit
			{
				height:30px;
				width:280px;
				margin-top:15px;
				background-image:Linear-Gradient(to bottom left,#4380B8,#00CA79);
			}
		</style>
	</head>
	<body>
		<div class="form">
			<div class="f1">
				<div class="title">
					Forgot Password
				</div>
				<div class="h3">
					Enter your email and we'll send you a link to reset your password
				</div>
				<div class="f2">
					<div class="h1"><br><input type="text" id="txtname" name="txtname" value="" placeholder="Enter your E-mail Id"/></div>
				</div>
				<div class="f2">
					<input class="h" type="submit" id="btnsubmit" name="btnsubmit" value="SUBMIT" />
					<div class="h3"><a href="login.php">Back to login</div>
				</div>
			</div>
		</div>
	</body>
</html>