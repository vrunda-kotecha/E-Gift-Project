<?php
	ob_start();
?>
<head>
 <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
       <!--CUSTOM BASIC STYLES-->
    <link href="assets/css/basic.css" rel="stylesheet" />
    <!--CUSTOM MAIN STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
        <!-- /. NAV SIDE  -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
	<style>
		
	</style>
</head>

<body>
    <div id="wrapper">
        <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">E-GIFT</a>
            </div>

            
        </nav>
        <!-- /. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                    <li>
                        
                            <img src="admin.jpg" class="img-thumbnail" />
                        
                    </li>

                    <li>
                        <a class="active-menu" href="index.php"><i class="fa fa-dashboard "></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-plus "></i>Create <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="cadmin.php"><i class="fa fa-desktop "></i>Admin</a>
                            </li>
                            <li>
                                <a href="cbuyer.php"><i class="fa fa-child"></i>Buyer</a>
                            </li>
                             <li>
                                <a href="cseller.php"><i class="fa fa-child "></i>Seller</a>
                            </li>
                             <li>
                                <a href="ccategory.php"><i class="fa fa-bars "></i>Category</a>
                            </li>
							<li>
                                <a href="cbrand.php"><i class="fa fa-users"></i>Recepient</a>
                            </li>
                             <li>
                                <a href="cgift.php"><i class="fa fa-gift "></i>Gift</a>
                            </li>
                             <li>
                                <a href="corder.php"><i class="fa fa-truck "></i>Order</a>
                            </li>
                        </ul>
                    </li>
                     <li>
                        <a href="#"><i class="fa fa-check "></i>Manage<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="madmin.php"><i class="fa fa-desktop "></i>Admin</a>
                            </li>
                            <li>
                                <a href="mbuyer.php"><i class="fa fa-child "></i>Buyer</a>
                            </li>
                             <li>
                                <a href="mseller.php"><i class="fa fa-child "></i>Seller</a>
                            </li>
                             <li>
                                <a href="mcategory.php"><i class="fa fa-bars "></i>Category</a>
                            </li>
                             <li>
                                <a href="mbrand.php"><i class="fa fa-users"></i>Recepient</a>
                            </li>
                             <li>
                                <a href="mgift.php"><i class="fa fa-gift "></i>Gift</a>
                            </li>
                             <li>
                                <a href="morder.php"><i class="fa fa-truck "></i>Order</a>
                            </li>
                            </ul>
							<li>
                        <a href="#"><i class="fa fa-eye "></i>Show<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="sadmin.php"><i class="fa fa-desktop "></i>Admin</a>
                            </li>
                            <li>
                                <a href="sbuyer.php"><i class="fa fa-child "></i>Buyer</a>
                            </li>
                             <li>
                                <a href="sseller.php"><i class="fa fa-child "></i>Seller</a>
                            </li>
                             <li>
                                <a href="scategory.php"><i class="fa fa-bars "></i>Category</a>
                            </li>
                            <li>
                                <a href="sbrand.php"><i class="fa fa-users"></i>Recepient</a>
                            </li>
                             <li>
                                <a href="sgift.php"><i class="fa fa-gift "></i>Gift</a>
                            </li>
                             <li>
                                <a href="sorder.php"><i class="fa fa-truck "></i>Order</a>
                            </li>
                           </ul>
                        <li>
                       
                    <li>
                        <a href="#"><i class="fa fa-eyedropper"></i>Search<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="seadmin.php"><i class="fa fa-desktop "></i>Admin</a>
                            </li>
                            <li>
                                <a href="sebuyer.php"><i class="fa fa-child "></i>Buyer</a>
                            </li>
                             <li>
                                <a href="seseller.php"><i class="fa fa-child "></i>Seller</a>
                            </li>
                             <li>
                                <a href="secategory.php"><i class="fa fa-bars "></i>Category</a>
                            </li>
                             <li>
                                <a href="sebrand.php"><i class="fa fa-users"></i>Recepient</a>
                            </li>
                             <li>
                                <a href="segift.php"><i class="fa fa-gift "></i>Gift</a>
                            </li>
                             <li>
                                <a href="seorder.php"><i class="fa fa-truck "></i>Order</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><i class="fa fa-ban "></i>Block/Unblock<span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="badmin.php"><i class="fa fa-desktop "></i>Admin</a>
                            </li>
                            <li>
                                <a href="bbuyer.php"><i class="fa fa-child "></i>Buyer</a>
                            </li>
                        </ul>
                    </li>
					 <li>
                        <a href="#"><i class="fa fa-user"></i>Profile <span class="fa arrow"></span></a>
                         <ul class="nav nav-second-level">
                            <li>
                                <a href="mprofile.php"><i class="fa fa-camera "></i>My Profile</a>
                            </li>
                            <li>
                                <a href="uprofile.php"><i class="fa fa-sliders "></i>Update Profile</a>
                            </li>
                             <li>
                                <a href="cpassword.php"><i class="fa fa-gears "></i>Change Password</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="logout.php"><i class="fa fa-sign-in "></i>Logout</a>
                    </li>
                </ul>

            </div>

        </nav>