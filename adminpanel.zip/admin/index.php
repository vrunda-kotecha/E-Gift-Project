﻿<?php
    ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Project Admin</title>
    <?php
        include('header.php');
    ?>
    <style>
    #page-wrapper {
        min-height: 100vh;
        background-color: #f8f9fa;
        
    }

    h3 {
        margin-bottom: 30px;
        font-weight: bold;
    }
    .footer{
        margin-top:600px;
    }
    </style>
</head>
<body>
<div class="container-fluid" id="page-wrapper">
    <div class="container py-5" id="page-inner">

        <!-- Welcome Message -->
        <div class="row mb-4">
            <div class="col-12 text-center">
                <h3 class="text-dark">
                    Welcome, 
                    <?php
                        session_start();
                        if (!isset($_SESSION['admin'])) {
                            header("Location:login.php");
                        } else {
                            echo htmlspecialchars($_SESSION['admin']);
                        }
                    ?>
                </h3>
            </div>
        </div>

<div class="footer">     
<?php
    include('footer.php');
?>
<div>
</body>
</html>