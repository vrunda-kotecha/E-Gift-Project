<?php
    ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <title>Login Page</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- FontAwesome -->
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

    <style>
        body {
            background: linear-gradient(to bottom left, #4380B8, #00CA79);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .login-box {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
        }
        .login-title {
            font-family: Calibri, sans-serif;
            font-size: 25px;
            text-align: center;
            margin-bottom: 20px;
        }
        .form-label {
            font-family: Calibri, sans-serif;
        }
        .btn-custom {
            background: linear-gradient(to bottom left, #4380B8, #00CA79);
            border: none;
        }
    </style>

    <script>
        function funlogin() {
            const txtname = document.getElementById('txtname');
            const password = document.getElementById('password');

            if (txtname.value === "") {
                alert("Please enter your Username");
                txtname.style.border = '2px solid black';
                txtname.focus();
                return false;
            }
            if (password.value === "") {
                alert("Please enter your Password");
                password.style.border = '2px solid black';
                password.focus();
                return false;
            }
            return true;
        }
    </script>
</head>

<body>
<div class="container">
    <div class="login-box">
        <?php
            if (isset($_POST['btnsubmit'])) {
                if (empty($_POST['txtname'])) {
                    echo "<div class='alert alert-danger'>Please Enter your Username</div>";
                } else if (empty($_POST['password'])) {
                    echo "<div class='alert alert-danger'>Please Enter your Password</div>";
                } else {
                    $un = $_POST['txtname'];
                    $pwd = $_POST['password'];
                    $sql = "SELECT * FROM tbladminreg WHERE username='$un' AND password='$pwd' AND status=1";
                    include('dbcon.php');
                    $result = mysqli_query($con, $sql);
                    $count = mysqli_num_rows($result);
                    if ($count == 1) {
                        session_start();
                        $_SESSION['admin'] = $un;
                        header('location:index.php');
                    } else {
                        echo "<div class='alert alert-danger'>Invalid Username or Password</div>";
                    }
                }
            }
        ?>
        <form method="POST" onsubmit="return funlogin();">
            <div class="login-title">
                <i class="fas fa-user-tie" style="color: #B197FC;"></i> Login
            </div>
            <div class="mb-3">
                <label for="txtname" class="form-label">Username</label>
                <input type="text" class="form-control" id="txtname" name="txtname" placeholder="Enter your username">
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password">
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-custom text-white" name="btnsubmit">LET ME IN</button>
            </div>
            <div class="text-center mt-3">
                Not registered? <a href="registration.php">Create an account</a>
            </div>
        </form>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>