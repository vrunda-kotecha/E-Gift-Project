<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Manage Buyers</title>
		<?php
			include ('header.php');
		?>
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage Buyers</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
							<div class="panel-heading">
							</div>
							<div class="panel-body">
								<?php
								$sql="SELECT * FROM tblbuyer";
								include ('dbcon.php');
								$result=mysqli_query($con,$sql);
								$count=mysqli_num_rows($result);
								
								if ($count==0)
								{
									echo "<h4 style=\"color:red\"> NO RECORDS FOUND</h4>";
								}
								else 
								{
									echo "<h4 style=\"color:green\"> TOTAL $count RECORDS FOUND</h4>";
								}
								echo "<table class=\"table\">
									<tr>
										<th>ACTION</th>
										<th>ID</th>
										<th>NAME</th>
										<th>USERNAME</th>
										<th>GENDER</th>
										<th>BIRTHDATE</th>
										<th>ADDRESS</th>
										<th>PINCODE</th>
										<th>MOBILENO</th>
										<th>PHOTO</th>
										<th>STATUS</th>
										<th>DATE</th>
									</tr>";
									while($line=mysqli_fetch_array($result))
									{
										$id=$line['itemid'];
										echo "<tr>";
										echo "<td>
										<a href=\"editbuyer.php?id=$id\"><img src=\"edit.jpeg\" type=\"submit\" class=\"btn\" value=\"EDIT\"/></a>
										<a href=\"deletebuyer.php?id=$id\"><img src=\"delete1.jpeg\"  class=\"btn\" value=\"DELETE\"/></a>";
										echo "</td><td>";
										echo $line ['itemid'];
										echo "</td><td>";
										echo $line ['fullname'];
										echo "</td><td>";
										echo $line ['username'];
										echo "</td><td>";
										echo $line ['gender'];
										echo "</td><td>";
										echo $line ['birthdate'];
										echo "</td><td>";
										echo $line ['address'];
										echo "</td><td>";
										echo $line ['pincode'];
										echo "</td><td>";
										echo $line['mobileno'];
										echo "</td><td><img style=\"height:100px;width:120px;\" src=\"";
										echo $line['photo'];
										echo "\" /></td><td>";
										echo $line ['status'];
										echo "</td><td>";
										echo $line ['cdate'];
										echo "</td><td>";
									}
									echo "</table>";
							?>
							</div>
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
