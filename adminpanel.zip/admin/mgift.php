<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Manage Gifts</title>
		<?php
			include ('header.php');
		?>
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Manage Gifts</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
							<div class="panel-heading">
							</div>
							<div class="panel-body">
								<?php
								$sql="SELECT * FROM tblgift";
								include ('dbcon.php');
								$result=mysqli_query($con,$sql);
								$count=mysqli_num_rows($result);
								
								if ($count==0)
								{
									echo "<h4 style=\"color:red\"> NO RECORDS FOUND</h4>";
								}
								else 
								{
									echo "<h4 style=\"color:green\"> TOTAL $count RECORDS FOUND</h4>";
								}
								echo "<table class=\"table\">
									<tr>
										<th>ACTION</th>
										<th>ID</th>
										<th>NAME</th>
										<th>CATEGORYID</th>
										<th>BRANDID</th>
										<th>DESCRIPTION</th>
										<th>PHOTO</th>
										<th>HEIGHT</th>
										<th>WIDTH</th>
										<th>PRICE</th>
										<th>QUANTITY</th>
										<th>STATUS</th>
										<th>DATE</th>
									</tr>";
									while($line=mysqli_fetch_array($result))
									{
										$id=$line['gid'];
										echo "<tr>";
										echo "<td>
										<a href=\"editgift.php?id=$id\"><img src=\"edit.jpeg\" type=\"submit\" class=\"btn\" value=\"EDIT\"/></a>
										<a href=\"deletegift.php?id=$id\"><img src=\"delete1.jpeg\"  class=\"btn\" value=\"DELETE\"/></a>";
										echo "</td><td>";
										echo $line ['gid'];
										echo "</td><td>";
										echo $line ['giftname'];
										echo "</td><td>";
										echo $line ['categoryid'];
										echo "</td><td>";
										echo $line ['brandid'];
										echo "</td><td>";
										echo $line ['description'];
										echo "</td><td><img style=\"height:100px;width:120px;\" src=\"";
										echo $line['giftphoto'];
										echo "\" /></td><td>";
										echo $line ['height'];
										echo "</td><td>";
										echo $line ['width'];
										echo "</td><td>";
										echo $line ['price'];
										echo "</td><td>";
										echo $line ['quantity'];
										echo "</td><td>";
										echo $line ['status'];
										echo "</td><td>";
										echo $line ['cdate'];
										echo "</td><td>";
									}
									echo "</table>";
							?>
							</div>
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
