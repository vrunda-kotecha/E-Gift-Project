<?php
ob_start();
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewResponsiveport" content="width=device-width, initial-scale=1.0" />
    <title>My Profile</title>
<?php
	include('header.php');
?>
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">My Profile</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
     <div class="panel-heading">
     </div>
                        <div class="panel-body">
  
                    <form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
		
					 <?php
					    include('dbcon.php');
						$un=$_SESSION['admin'];
	                    $sql="SELECT * FROM tbladminreg where username='$un'";
						$result=mysqli_query($con,$sql);
						echo"<table class=\"table table-striped table-success\">";
                        while($line=mysqli_fetch_array($result))
                        {	$id=$line['adminid'];
							$name=$line['fullname'];
							$photo=$line['photo'];
							$username=$line['username'];
							$email=$line['emailid'];
							$mobile=$line['mobileno'];
							$regdate=$line['cdate'];
							
							echo"<tr>";
							echo"<tr><td colspan=\"2\">";
			                echo "<img src=\"$photo\" style=\"height:300px;width:250px;\"class=\"p\"  />";
							echo"</td>";
							
							echo"<tr><td>id</td>";
			                echo"<td>";
			                echo $id;
			                echo"</td>";
			                echo"</tr>";

                            echo"<tr><td>User Name</td>";
			                echo"<td>";
			                echo $line['fullname'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>User Name</td>";
			                echo"<td>";
			                echo $line['username'];
			                echo"</td>";
			                echo"</tr>";
							
							
							
							echo"<tr><td>Email Id</td>";
			                echo"<td>";
			                echo $line['emailid'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Mobile No</td>";
							echo"<td>";
			                echo $line['mobileno'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Regdate</td>";
			                echo"<td>";
			                echo $line['cdate'];
			                echo"</td>";
			                echo"</tr>";
							
							echo"<tr><td>Status</td>";
			                echo"<td>";
			                echo $line['status'];
			                echo"</td>";
			                echo"</tr>";
							
							
						}
                        echo"</table>";
                       ?>			
					 
                    </div>
                </div>              
               </div>
            </div>     
           <!-- /. ROW  -->            
               
<?php
	include('footer.php');
?>
</body>
</html>