<html>
	<head>
		<title>PAYMENT GATEWAY</title>
		<script>
						 function buildPaymentRequest(payments) {
			   return payments.paymentRequest({
				 countryCode: 'US',
				 currencyCode: 'USD',
				 total: {
				   amount: '1.00',
				   label: 'Total',
				 },
			   });
			 }

			 async function initializeGooglePay(payments) {
			   const paymentRequest = buildPaymentRequest(payments)

			   const googlePay = await payments.googlePay(paymentRequest);
			   await googlePay.attach('#google-pay-button');

			   return googlePay;
			 }
		</script>
	</head>
	<body>
		<form id="payment-form">
		   <!-- Add the google-pay-button div below -->
		   <div id="google-pay-button"></div>
		   <div id="card-container"></div>
		   <button id="card-button" type="button">Pay $1.00</button>
		</form>
		<div id="payment-status-container"></div>
	</body>
</html>