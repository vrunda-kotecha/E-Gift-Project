<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: linear-gradient(to bottom left, #4380B8, #00CA79);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .form-container {
      background-color: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 600px;
    }
    .form-title {
      font-family: Calibri, sans-serif;
      font-size: 28px;
      margin-bottom: 20px;
      text-align: center;
    }
  </style>
</head>
<body>

<div class="container">
  <?php
  if (isset($_POST['btnsubmit'])) {
    if (empty($_POST['txtfullname'])) {
      echo "<div class='alert alert-danger'>Please Enter your Fullname</div>";
    } else if (empty($_POST['txtusername'])) {
      echo "<div class='alert alert-danger'>Please Enter your Username</div>";
    } else if (empty($_POST['txtpassword'])) {
      echo "<div class='alert alert-danger'>Please Enter your Password</div>";
    } else if (empty($_POST['txtconfirmpassword'])) {
      echo "<div class='alert alert-danger'>Please Enter your Confirm Password</div>";
    } else if ($_POST['txtpassword'] != $_POST['txtconfirmpassword']) {
      echo "<div class='alert alert-danger'>Password and Confirm Password are not the same</div>";
    } else if (empty($_POST['txtemailid'])) {
      echo "<div class='alert alert-danger'>Please Enter your Email-id</div>";
    } else if (empty($_POST['txtmobileno'])) {
      echo "<div class='alert alert-danger'>Please Enter your Mobile Number</div>";
    } else if (empty($_FILES['file']['name'])) {
      echo "<div class='alert alert-danger'>Please Insert your Photo</div>";
    } else {
      $fn = $_POST['txtfullname'];
      $un = $_POST['txtusername'];
      $pwd = $_POST['txtpassword'];
      $eml = $_POST['txtemailid'];
      $mo = $_POST['txtmobileno'];
      $ph = "google.jpg";
      $s = 0;
      $d = date('Y-m-d H:i:s');

      include('dbcon.php');

      $sql = "INSERT INTO tbladminreg VALUES (NULL, '$fn', '$un', '$pwd', '$eml', '$mo', '$ph', '$s', '$d')";
      if (mysqli_query($con, $sql)) {
        echo "<div class='alert alert-success'>New Admin Registered</div>";
      } else {
        echo "<div class='alert alert-danger'>ERROR</div>";
      }
    }
  }
  ?>

  <form class="form-container" method="POST" action="" enctype="multipart/form-data">
    <div class="form-title">Registration</div>
    <div class="row mb-3">
      <div class="col">
        <label for="txtfullname" class="form-label">Full Name</label>
        <input type="text" class="form-control" id="txtfullname" name="txtfullname" placeholder="Enter your name" value="<?php if(isset($_POST['txtfullname'])) echo $_POST['txtfullname']; ?>">
      </div>
      <div class="col">
        <label for="txtusername" class="form-label">Username</label>
        <input type="text" class="form-control" id="txtusername" name="txtusername" placeholder="Enter your username" value="<?php if(isset($_POST['txtusername'])) echo $_POST['txtusername']; ?>">
      </div>
    </div>

    <div class="row mb-3">
      <div class="col">
        <label for="txtemailid" class="form-label">Email</label>
        <input type="email" class="form-control" id="txtemailid" name="txtemailid" placeholder="Enter your email" value="<?php if(isset($_POST['txtemailid'])) echo $_POST['txtemailid']; ?>">
      </div>
      <div class="col">
        <label for="txtmobileno" class="form-label">Phone Number</label>
        <input type="text" class="form-control" id="txtmobileno" name="txtmobileno" placeholder="Enter your number" value="<?php if(isset($_POST['txtmobileno'])) echo $_POST['txtmobileno']; ?>">
      </div>
    </div>

    <div class="row mb-3">
      <div class="col">
        <label for="txtpassword" class="form-label">Password</label>
        <input type="password" class="form-control" id="txtpassword" name="txtpassword" placeholder="Enter your password">
      </div>
      <div class="col">
        <label for="txtconfirmpassword" class="form-label">Confirm Password</label>
        <input type="password" class="form-control" id="txtconfirmpassword" name="txtconfirmpassword" placeholder="Confirm your password">
      </div>
    </div>

    <div class="mb-3">
      <label for="file" class="form-label">Upload Photo</label>
      <input class="form-control" type="file" id="file" name="file">
    </div>

    <div class="d-grid">
      <button type="submit" class="btn btn-lg" style="background: linear-gradient(to bottom left, #4380B8, #00CA79);" name="btnsubmit">SUBMIT</button>
    </div>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>