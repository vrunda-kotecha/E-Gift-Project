<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Search Brands</title>
		<?php
			include ('header.php');
		?>
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Search Brands</h1>
                        <h3 style="color:green">Welcome, 
							<?php
								session_start();
								if(!isset($_SESSION['admin']))
								{
									header("Location:login.php");
								}
								else
								{
									echo $_SESSION['admin'];
								}
							?>

						</h3>
							<div class="panel-heading">
								<form id="form1" name="form1" method="POST" action="">
									<div class="form-group">
										<label>Enter Seach Item</label>
										<input id="txtsearch" name="txtsearch" class="form-control" type="text" value="<?php if(isset($_POST['txtsearch'])) echo $_POST['txtsearch']; ?>"/>
									</div>
										<input id="btnsubmit" name="btnsubmit" type="submit" class="btn" value="SUBMIT"/>
								</form>
							</div>
							<div class="panel-body">
								<?php
			$sql="select * from tblbrand";
			if(isset ($_POST ['btnsubmit']))
			{
				$s=$_POST ['txtsearch'];
				$s="%".$s."%";
				$sql="select * from tblbrand where brandname like '$s'";
			}
			include('dbcon.php');
			$result=mysqli_query($con,$sql);
			$count=mysqli_num_rows($result);
								
								if ($count==0)
								{
									echo "<h4 style=\"color:red\"> NO RECORDS FOUND</h4>";
								}
								else 
								{
									echo "<h4 style=\"color:green\"> TOTAL $count RECORDS FOUND</h4>";
								}
								echo "<table class=\"table\">
									<tr>
										<th>ID</th>
										<th>NAME</th>
										<th>STATUS</th>
										<th>REGDATE</th>
									</tr>";
									while($line=mysqli_fetch_array($result))
									{
										echo "<tr>";
										echo "<td>";
										echo $line ['itemid'];
										echo "</td><td>";
										echo $line ['brandname'];
										echo "</td><td>";
										echo $line ['status'];
										echo "</td><td>";
										echo $line ['cdate'];
										echo "</td><td>";
									}
									echo "</table>";
							?>
  </div>
							</div>
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
