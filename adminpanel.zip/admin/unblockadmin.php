<?php
	 ob_start();
	 include('dbcon.php');
	 $id=$_REQUEST['id'];
	 $s="update tbladminreg set status=1 where adminid='$id'";
	 if(mysqli_query($con,$s))
	 {
		 header("location:badmin.php",true);
	 }
?>