<html>
	<head>
		<style>
			.box
			{
				background-color:#F5E3E5;
				margin-top:20px;
				height:350px;
			}
			.box1
			{
				background-color:#F5E3E5;
				margin-top:20px;
				
			}
			.content
			{
				margin-left:20px;
				margin-right:20px
				
			}
			.ph
			{
				margin-left:30px;
			}
			#name
			{
				width:400px;
				height:50px;
			}
			#txtopassword
			{
				width:400px;
				height:50px;
			}
			#txtnpassword
			{
				width:400px;
				height:50px;
			}
			#txtnconfirmpassword
			{
				width:400px;
				height:50px;
			}
			#btnupdate
			{
				width:190px;
				height:50px;
				background-color:DD2745;
				color:white;
				margin-top:10px;
				margin-bottom:10px;
			}
			#btncancel
			{
				width:230px;
				height:40px;
				background-color:white;
				color:black;
				margin-top:10px;
				border-radius:4px;
				margin-bottom:10px;
				margin-right:20px;
				padding:14px;
				padding-left:60px;
				padding-right:60px;
			}
		</style>
	</head>
<?php
			include ('header.php');
?>

<?php
	if(!isset($_SESSION['buyer']))
	{
		header("Location:login.php");
	}
?>

    <div class="row">  
		<div class="col-md-3">
			<div class="box">
				<div class="content">
				<a href="myaccount.php" style="color:black">
					<hr>
						My profile
				</a>
					<br>
					<hr>
				<a href="editaccount.php" style="color:black">
						Edit Profile
				</a>
					<br>
					<hr>
				<a href="changepassword.php" style="color:black">
						Change Password
				</a>
					<br>
					<hr>
				<a href="orderhistory.php" style="color:black">
						Order History
				</a>
					<hr>
					<a href="index.php" style="color:black">
						Back to Home
				</a>
				<br>
					<hr>
				<a href="shop.php" style="color:black">
						Browse Gifts
				</a>
				</div>
			</div>
		</div>
		<div class="col-md-9">
			<div class="box1">
			<form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
					<?php
									if (isset($_POST['btnupdate']))
									{
										$un=$_SESSION['buyer'];
										$opass=$_POST['txtopassword'];
										$npass=$_POST['txtnpassword'];
										$ncpass=$_POST['txtnconfirmpassword'];
									
									
									if(empty($opass))
									{
										echo"<p style=\"color:red; text-align:center; \">Please Enter Old Password</p>";
									}
									else if(empty($npass))
									{
										echo"<p style=\"color:red; text-align:center; \">Please Enter New Password</p>";
									}
									else if(empty($ncpass))
									{
										echo"<p style=\"color:red; text-align:center; \">Please Enter New Confirm Password</p>";
									}
									else if ($npass!=$ncpass)
									{
											echo "<h3 style=\"color:red;\">Password and Confirm Password are not the same</h3>";
									}
										else
										{
											include('dbcon.php');
											$sql="UPDATE tblbuyer SET password='$npass' where username='$un' and password='$opass';";
											if(mysqli_query($con,$sql))
											{
												echo"<h4 style=\"color:green; text-align:center;\">New Password Changed Successfully!</h4>";
											  
												echo'<script>clearinputs();</script>';
											}								  
											else
											{
												echo"<h4 style=\"color:red; text-align:center;\">Error</h4>";
											}
										}
										}
								?>
					  <form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
			<?php
					    include('dbcon.php');
						$un=$_SESSION['buyer'];
	                    $sql="SELECT * FROM tblbuyer where username='$un'";
						$result=mysqli_query($con,$sql);
						echo"<div class=\"row\">";
                        while($line=mysqli_fetch_array($result))
                        {	
							$photo=$line['photo'];
							
							
							echo "<div class=\"col-md-4\">";
			                echo "<img src=\"$photo\" style=\"width:200px;height:200px;border-radius:50%;margin:30px\"class=\"p\"  />";
							echo "</div>";
							echo "<div class=\"col-md-8\" style=\"margin-top:30px\">";
							 
						}
							?>
							
							<div class="panel-body">
							<form id="form1" name="form1" method="POST" action="">
								
								<div class="form-group">
									<label>Enter Old Password</label>
									<input id="txtopassword" name="txtopassword" class="form-control" type="password" value="<?php if(isset($_POST['txtopassword'])) echo $_POST['txtopassword']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter New Password</label>
									<input id="txtnpassword" name="txtnpassword" class="form-control" type="password" value="<?php if(isset($_POST['txtpassword'])) echo $_POST['txtpassword']; ?>"/>
								</div>
								<div class="form-group">
									<label>Enter Confirm New Password</label>
									<input id="txtnconfirmpassword" name="txtnconfirmpassword" class="form-control" type="password" value="<?php if(isset($_POST['txtconfirmpassword'])) echo $_POST['txtconfirmpassword']; ?>"/>
								</div>
								<div>
									<a href="myaccount.php" id="btncancel">
										CANCEL
									</a>
									<input id="btnupdate" name="btnupdate" type="submit" class="btn" value="UPDATE"/>
								</div>
							</form>
						</div>
						
						
						</div>
						
						
						
						
                        </div>
                       
			</div>
		</div>
	</div>

</html>