 <?php
	include('header.php');
?>
<style>
   .p
   {
	   height:200px;
	   width:200px;
	   text-align:center;
	   border:5px solid white;
	   border-radius:20px;
	   transition:1.5s ease-in-out;
   }
   
	 .txt 
    { 
		 color:black;
  }
  .text
  {
	  border-bottom:none;
	  border-top:none;
	  border-left:none;
	  border-right:none;
	  width:150px;
	  margin-top:80px;
	  background-color:#F2F2F2;
  }
  .text1
  {
	  border-bottom:none;
	  border-top:none;
	  border-left:none;
	  border-right:none;
	  width:30px; 
	  height:25px;
	  text-align:center; 
	  background-color:#F2F2F2;
	  margin-top:90px;
  }
 .text2
 {
	 width:130px;
	 margin-top:90px;
	 background-color:#F2F2F2;
 }
 .text4
 {
	 width:130px;
	 margin-top:90px;
	 
	 background-color:#E3DDF2;
			color:#6D4EBF;
			border:solid 1px #6D4EBF;
 }
 .text3
 {
	 width:35px;
	 border-bottom:none;
	  border-top:none;
	  border-left:none;
	  border-right:none;
	  margin-top:90px;
	  background-color:#F2F2F2;
 }
 .remove
 {
	 width:50px;
	 height:50px;
	 margin-top:90px;
 }
 
 
 
 
		.img
		{
			margin-top:50px;
		}
		.h
		{
			font-family:Georgia;
			font-weight:bold;
			text-align:center;
			margin-top:30px;
		}
		.h1
		{
			font-family:Calibri;
			text-align:center;
			font-size:20px;
		}
		h6
		{
			font-family:Calibri;
			text-align:left;
			margin-left:100px;
			margin-top:50px;
			color:#6D4EBF;
			font-weight:bold;
		}
		.menu
		{
		 color:#C3BDBD;
		}
		hr
		{
			width:220px;
			margin-left:200px;
			margin-top:50px;
		}
		.box1
		{
			height:100px;
			width:100px;
			margin-left:100px;
			margin-top:20px;
		}
		.img-box1
		{
			height:100px;
			width:100px;
		}
		
		.icon
		{
			margin-left:80px;
			margin-right:10px;
			color: #6D4EBF;
		}
		#add
		{
			background-color:#E3DDF2;
			color:#6D4EBF;
			border:solid 1px #6D4EBF;
			width:120px;
			margin-left:10px;

		}
		.s
		{
			margin-bottom:30px;
		}
		.r
		{
			margin-bottom:70px;
		}
		.r1
		{
			font-size:20px;
			font-weight:bold;
			height:100px;
		}
		.r3
		{
			padding:35px;
		}
		.img1
		{
			height:230px;
			width:230px;
		}
		#btnporder
	{
		background-color: #DD2745; 
		border: none;
		color: white;
		width:350px;
		height:50px;
		padding: 10px 32px;
		text-align: center;
		text-decoration: none;
		font-weight:bold;
		display: inline-block;
		font-size: 14px;
	}
	.info
	{
		border:solid 1px;
		height:240px;
		width:900px;
	}
</style>
<script>
	
	function quantity11()
	{
		total1.value=parseInt(amount1.value)*parseInt(quantity1.value);
		return false;
	}
	
	
	function fun1()
	{
		quantity1.value=parseInt(quantity1.value)-1;
		if(quantity1.value<1)
		{
			quantity1.value=1;
		}
		total1.value=parseInt(amount1.value)*parseInt(quantity1.value);
		return false;
	}
	function fun2()
	{
		quantity2.value=parseInt(quantity2.value)-1;
		if(quantity2.value<1)
		{
			quantity2.value=1;
		}
		total2.value=parseInt(amount2.value)*parseInt(quantity2.value);
		return false;
	}
	function fun3()
	{
		quantity3.value=parseInt(quantity3.value)-1;
		if(quantity3.value<1)
		{
			quantity3.value=1;
		}
		total3.value=parseInt(amount3.value)*parseInt(quantity3.value);
		return false;
	}
	function fun4()
	{
		quantity4.value=parseInt(quantity4.value)-1;
		if(quantity4.value<1)
		{
			quantity4.value=1;
		}
		total4.value=parseInt(amount4.value)*parseInt(quantity4.value);
		return false;
	}
	function fun5()
	{
		quantity5.value=parseInt(quantity5.value)-1;
		if(quantity5.value<1)
		{
			quantity5.value=1;
		}
		total5.value=parseInt(amount5.value)*parseInt(quantity5.value);
		return false;
	}
	function fun6()
	{
		quantity6.value=parseInt(quantity6.value)-1;
		if(quantity6.value<1)
		{
			quantity6.value=1;
		}
		total6.value=parseInt(amount6.value)*parseInt(quantity6.value);
		return false;
	}
	function fun7()
	{
		quantity7.value=parseInt(quantity7.value)-1;
		if(quantity7.value<1)
		{
			quantity7.value=1;
		}
		total7.value=parseInt(amount7.value)*parseInt(quantity7.value);
		return false;
	}
	function fun8()
	{
		quantity8.value=parseInt(quantity8.value)-1;
		if(quantity8.value<1)
		{
			quantity8.value=1;
		}
		total8.value=parseInt(amount8.value)*parseInt(quantity8.value);
		return false;
	}
	function fun9()
	{
		quantity9.value=parseInt(quantity9.value)-1;
		if(quantity9.value<1)
		{
			quantity9.value=1;
		}
		total9.value=parseInt(amount9.value)*parseInt(quantity9.value);
		return false;
	}
	function fun10()
	{
		quantity10.value=parseInt(quantity10.value)-1;
		if(quantity10.value<1)
		{
			quantity10.value=1;
		}
		total10.value=parseInt(amount10.value)*parseInt(quantity10.value);
		return false;
	}

	function fun21()
	{
		quantity1.value=parseInt(quantity1.value)+1;
		total1.value=parseInt(amount1.value)*parseInt(quantity1.value);
        return false;
	}
	function fun22()
	{
		quantity2.value=parseInt(quantity2.value)+1;
		total2.value=parseInt(amount2.value)*parseInt(quantity2.value);
        return false;
	}
	function fun23()
	{
		quantity3.value=parseInt(quantity3.value)+1;
		total3.value=parseInt(amount3.value)*parseInt(quantity3.value);
        return false;
	}
	function fun24()
	{
		quantity4.value=parseInt(quantity4.value)+1;
		total4.value=parseInt(amount4.value)*parseInt(quantity4.value);
        return false;
	}
	function fun25()
	{
		quantity5.value=parseInt(quantity5.value)+1;
		total5.value=parseInt(amount5.value)*parseInt(quantity5.value);
        return false;
	}
	function fun26()
	{
		quantity6.value=parseInt(quantity6.value)+1;
		total6.value=parseInt(amount6.value)*parseInt(quantity6.value);
        return false;
	}
	function fun27()
	{
		quantity7.value=parseInt(quantity7.value)+1;
		total7.value=parseInt(amount7.value)*parseInt(quantity7.value);
        return false;
	}
	function fun28()
	{
		quantity8.value=parseInt(quantity8.value)+1;
		total8.value=parseInt(amount8.value)*parseInt(quantity8.value);
        return false;
	}
	function fun29()
	{
		quantity9.value=parseInt(quantity9.value)+1;
		total9.value=parseInt(amount9.value)*parseInt(quantity9.value);
        return false;
	}
	function fun30()
	{
		quantity10.value=parseInt(quantity10.value)+1;
		total10.value=parseInt(amount10.value)*parseInt(quantity10.value);
        return false;
	}
</script>

        <!-- /. NAV SIDE  -->
		       
        <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                    
					<?php
								
								$name=$_SESSION['buyer'];
								$sql="select * from tblcart where status=1 and username='$name'";
								include('dbcon.php');
								$result=mysqli_query($con,$sql);
								$count=mysqli_num_rows($result);
								
								
								if ($count == 0) {
									echo '<div class="row align-items-center" style="min-height:60vh;">';
									echo '  <div class="col-md-6 text-center">';
									echo '      <img src="images/ecart.png" class="img-fluid" alt="Empty Cart" />';
									echo '  </div>';
									echo '  <div class="col-md-6 text-center">';
									echo '      <h2 class="fw-bold">Your Gift Box Looks Empty</h2>';
									echo '      <p class="lead">Let\'s fill it up! Shall we?</p>';
									echo '      <div class="d-flex justify-content-center mt-4">';
									echo '          <a href="index.php" class="btn btn-outline-secondary me-3">Go to Home</a>';
									echo '      </div>';
									echo '  </div>';
									echo '</div>';
									
									$sql="SELECT * FROM tblitemcategory where itemcatid<=3";
									include ('dbcon.php');
									$result=mysqli_query($con,$sql);
									$count=mysqli_num_rows($result);
								
								
									
								}
								
							?>
								
					 <?php
					  if (isset($_POST['btnporder']))
                      {
						$userid=1;
						include("dbcon.php");
						$name=$_SESSION['buyer'];
						
						$n=$_POST['txtcount'];
						$i=1;
						while ($i<=$n)
						{
							    $cid="cart$i";
								$productid="productid$i";
								$dec="dec$i";
								$rec="rec$i";
								$amount="amount$i";
								$quntity="quantity$i";
								$price="total$i";
								$addres="address$i";
								$pincode="pincode$i";
								$mobile="mobileno$i";
								$dec=$_POST[$dec];
								$rec=$_POST[$rec];
								$productid=$_POST[$productid];
								$amount=$_POST[$amount];
								$quntity=$_POST[$quntity];
								$price=$_POST[$price];
								$addres=$_POST[$addres];
								$pincode=$_POST[$pincode];
								$mobile=$_POST[$mobile];
								$cid=$_POST[$cid];
								$timeZone=new DateTimeZone("Asia/Kolkata");
								$date=new DateTime();
								$date->setTimeZone($timeZone);
								$d=$date->format('y-m-d h:i:s');
								$description=$rec." ".$dec;
								
							include('dbcon.php');
						    $sql="insert into tblorder(orderid,productid,quantity,price,total,description,username,address,pincode,mobileno,status,cdate)
						    values(NULL,'$productid','$quntity','$amount','$price','$description','$name','$addres','$pincode','$mobile',1,'$d')";
							if(mysqli_query($con,$sql))
							{
								$sql="update tblcart set status=0 where id=$cid";
								if(mysqli_query($con,$sql))
							{ 
								header("Location: paymentgateway.php?price=$price");
							}	
								
								echo"<h3 style=\"color:#CD223E;margin-top:20px; text-align:center;\">Your Order Is Placed Sucsessfully</h3>";
								echo"<h5 style=\"color:#CD223E;margin-top:10px; text-align:center;\">Thank you for shopping with Us!!</h5>";

							}
							else
							{
								echo"<p style=\"color:red; text-align:center;\">Error</p>";
							}
						$i=$i+1;	
					  }  
                   }
					 ?>
					 <!-- Place Order code End-->
					 
					</div>
     
					<div class="row">
  <div class="col-md-12">
    <form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
      <div class="table-responsive">
        <table class="table table-bordered table-hover" style="background-color:#F2F2F2;">
          <thead class="thead-light">
            <tr>
              <th>Image</th>
              <th>Hidden Fields</th>
              <th>Product Name</th>
              <th>Address</th>
              <th>Pincode</th>
              <th>Quantity</th>
              <th>Price</th>
              <th>Total</th>
              <th>Mobile No</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            include('dbcon.php');
            
            $sql="SELECT `tblcart`.`id` as `cartid`,`tblcart`.`status` as `cs`,`tblcart`.`recipient` as `rec`,`tblcart`.`ddate` as `dec`,`tblgift`.`gid` as `pid`,`tblgift`.`giftphoto` as `pphoto`,`tblgift`.`description` as `pname`,`tblgift`.`price` as `pprice`,`tblgift`.`quantity` as `pquantity`,`tblbuyer`.`address` as `uaddress`,`tblbuyer`.`pincode` as `upincode`,`tblbuyer`.`mobileno` as `umobileno`  FROM  `tblbuyer` inner join `tblgift` inner join `tblcart`   where `tblcart`.`username`=`tblbuyer`.`username` and `tblcart`.`productid`=`tblgift`.`gid` and `tblbuyer`.`username`='$name' ";
            $result=mysqli_query($con,$sql);
            $i=1;
            while($line=mysqli_fetch_array($result))
            {
              $caid=$line['cartid'];
              $cstatus=$line['cs'];
              $rec=$line['rec'];
              $dec=$line['dec'];
              $id2=$line['pid'];
              $name=$line['pname'];
              $quantity=1;
              $price=$line['pprice'];
              $photo=$line['pphoto'];
              $address=$line['uaddress'];
              $pincode=$line['upincode'];
              $mobileno=$line['umobileno'];
              
              if($cstatus==1)
              {
                $txtdec="dec$i";
                $txtrec="rec$i";
                $txtcid="cart$i";
                $txtpid="productid$i";
                $add="add$i";
                $txtam="amount$i";
                $txtq="quantity$i";
                $txtt="total$i";
                $txta="address$i";
                $txtp="pincode$i";
                $txtm="mobileno$i";
                $btnr="remove$i";
                $btnre="btnremove$i";
                $sub="sub$i";
                $fun="fun$i";
                $fun2="fun2$i";
                $quantity1="quantity$i";
                $i=$i+1;
                
                echo "<tr>";
                echo "<td><img src=\"$photo\" class=\"img-fluid\" style=\"max-width:100px; height:auto;\" /></td>";
                echo "<td>
                        <input type=\"hidden\" name=\"$txtcid\" id=\"$txtcid\" value=\"$caid\" />
                        <input type=\"hidden\" name=\"$txtpid\" id=\"$txtpid\" value=\"$id2\" />
                        <input type=\"hidden\" name=\"$txtrec\" id=\"$txtrec\" value=\"$rec\" />
                        <input type=\"hidden\" name=\"$txtdec\" id=\"$txtdec\" value=\"$dec\" />
                      </td>";
                echo "<td>
                        <textarea rows=\"2\" cols=\"30\" class=\"form-control-plaintext\" readonly>$name</textarea>
                      </td>";
                echo "<td>
                        <input type=\"text\" name=\"$txta\" id=\"$txta\" class=\"form-control\" value=\"$address\" />
                      </td>";
                echo "<td>
                        <input type=\"text\" name=\"$txtp\" id=\"$txtp\" class=\"form-control\" value=\"$pincode\" />
                      </td>";
                echo "<td class=\"text-center\">
                        <div class=\"d-flex align-items-center\">
                          <button type=\"button\" id=\"$sub\" onclick=\"return $fun();\" class=\"btn btn-outline-primary btn-sm\">-</button>
                          <input type=\"text\" name=\"$txtq\" id=\"$txtq\" class=\"form-control text-center mx-1\" style=\"width:60px;\" onkeyup=\"return $quantity1();\" value=\"$quantity\" />
                          <button type=\"button\" id=\"$add\" onclick=\"return $fun2();\" class=\"btn btn-outline-primary btn-sm\">+</button>
                        </div>
                      </td>";
                echo "<td>
                        <input type=\"hidden\" name=\"$txtam\" id=\"$txtam\" value=\"$price\" />
                      </td>";
                echo "<td>
                        <input type=\"text\" name=\"$txtt\" id=\"$txtt\" class=\"form-control\" style=\"width:80px;\" value=\"".$line['pprice']*$quantity."\" readonly />
                      </td>";
                echo "<td>
                        <input type=\"text\" name=\"$txtm\" id=\"$txtm\" class=\"form-control\" value=\"$mobileno\" />
                      </td>";
                echo "<td>
                        <a class=\"btn btn-danger btn-sm\" href=\"updatecart.php?id=$caid\"><i class=\"fa fa-trash\"></i></a>
                      </td>";
                echo "</tr>";
              }
            }
            echo "</tbody>";
            echo "</table>";
            
            $i=$i-1;
            if ($i>0)
            {
              echo "<input type=\"hidden\" name=\"txtcount\" id=\"txtcount\" value=\"$i\" />";
              echo "<div class=\"text-center\">
                      <button type=\"submit\" name=\"btnporder\" id=\"btnporder\" class=\"btn btn-success\">Place Order</button>
                    </div>";
            }
            ?>		
        </div>
    </form>
  </div>
</div>			

<?php
	include('footer.php');
?>

   
</body>
</html>