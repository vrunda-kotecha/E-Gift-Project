<?php

	ob_start();
	$con=mysqli_connect("localhost","root","","dbegift") or die ("Unable to connect to database");;
?>