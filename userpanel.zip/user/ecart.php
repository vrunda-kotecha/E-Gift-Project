<!doctype html>
<html lang="en">
  <head>
	
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ecart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
	<style>
		.img
		{
			margin-top:50px;
		}
		.h
		{
			font-family:Georgia;
			font-weight:bold;
			text-align:center;
		}
		.h1
		{
			font-family:Calibri;
			text-align:center;
			font-size:20px;
		}
		h6
		{
			font-family:Calibri;
			text-align:left;
			margin-left:100px;
			margin-top:50px;
			color:#6D4EBF;
			font-weight:bold;
		}
		.menu
		{
		 color:#C3BDBD;
		}
		hr
		{
			width:220px;
			margin-left:200px;
			margin-top:50px;
		}
		.box1
		{
			height:100px;
			width:100px;
			margin-left:100px;
			margin-top:30px;
		}
		.img-box1
		{
			height:100px;
			width:100px;
		}
		
		
	</style>
 </head>
  <body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
	<nav class="navbar navbar-expand-lg custom_nav-container ">
        <a class="navbar-brand" href="index.php">
          <h2 style="color:#CD223E;">
			e-gift
          </h2>
        </a>
          </div>
		  </nav>
    </header>
	<div class="row">
		<div class="col-md-6" >
			<img src="ecart.png" class="img"/>
		</div>
		<div class="col-md-6" >
			<h2 class="h">Your Gift Box Looks empty</h2> 
			<div class="h1">Lets fill it up! Shall we?</div>
			<hr>
		<div class="row">
			<div class="col-md-6" >
			<h6>Browse Collections</h6>
			</div>
			<div class="col-md-6" >
			<h6><a href="index.php" style="text-decoration: none;color:#C3BDBD" >Go to Home</a></h6>
			</div>
		</div>
		<?php
								$sql="SELECT * FROM tblitemcategory where itemcatid<=3";
								include ('dbcon.php');
								$result=mysqli_query($con,$sql);
								$count=mysqli_num_rows($result);
								
								
								echo "<div class=\"row\">";
								$counter=1;
								
									while($line=mysqli_fetch_array($result))
									{
										$id=$line['itemcatid'];
										echo "<div class=\"col-sm-6 col-md-4 col-lg-3\" style=\"border:solid 1px\">";
										echo "<div class=\"box1\">";
										echo "<div class=\"img-box1\">";
										echo "<a href=\"view.php?id=$id\"><img style=\"height:100px;width:100px;\" src=\"";
										echo $line['photo'];
										echo "\" /></a>";
										echo "</div>";
										echo "<div class=\"detail-box1\"><h5>";
										echo $line ['categoryname'];
										echo "</h5>";
										echo "</div>";
										echo "</div>";
										echo "</div>";
										if($counter%3==0)
										{
											echo "</div><div class=\"row\">";
										}
										$counter=$counter+1;
									}
									
									echo "</div>";
									
							?>
		</div>
	</div>
  </body>
</html>