<html>
	<head>
		<style>
			.box
			{
				background-color:#F5E3E5;
				margin-top:20px;
				height:350px;
			}
			.box1
			{
				background-color:#F5E3E5;
				margin-top:20px;
				
			}
			.content
			{
				margin-left:20px;
				margin-right:20px
				
			}
			.ph
			{
				margin-left:30px;
			}
			#name
			{
				width:400px;
				height:50px;
			}
			#btnupdate
			{
				width:400px;
				height:50px;
				background-color:DD2745;
				color:white;
				margin-top:20px;
				margin-bottom:10px;
			}
			#phbtn
			{
				width:100px;
				height:50px;
				background-color:DD2745;
				color:white;
				margin-top:10px;
			}
		</style>
	</head>
<?php
			include ('header.php');
?>

<?php
	if(!isset($_SESSION['buyer']))
	{
		header("Location:login.php");
	}
?>

    <div class="row">  
		<div class="col-md-3">
			<div class="box">
				<div class="content">
				<a href="myaccount.php" style="color:black">
					<hr>
						My profile
				</a>
					<br>
					<hr>
				<a href="editaccount.php" style="color:black">
						Edit Profile
				</a>
					<br>
					<hr>
				<a href="changepassword.php" style="color:black">
						Change Password
				</a>
					<br>
					<hr>
				<a href="orderhistory.php" style="color:black">
						Order History
				</a>
					<hr>
					<a href="index.php" style="color:black">
						Back to Home
				</a>
				<br>
					<hr>
				<a href="shop.php" style="color:black">
						Browse Gifts
				</a>
				</div>
			</div>
		</div>
		<div class="col-md-9">
			<div class="box1">
			<form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
			 <!-- photoupdate(edit) code start-->
					 <?php
					  if (isset($_POST['photoupdate']))
                      {
						   $un=$_SESSION['buyer'];
						   $path="1";
						  
					          $path="../image/".$_FILES['file']['name'];
							  if(file_exists("../image/".$_FILES['file']['name']))
							  {
								  echo"<p style=\"color:red; text-align:center; font-weight:bold\">File is not selected or Name Already Exits Please Rename the File and Try Again.</p>";
							  }
							  else
							  {
								  $allowed=array('gif','png','jpg','jpeg','JPG','PNG','GIF','JPEG');
								  $filename=$_FILES['file']['name'];
								  $ext=pathinfo($filename,PATHINFO_EXTENSION);
								  if(!in_array($ext,$allowed))
								  {
									  echo"<p style=\"color:red; text-align:center; font-weight:bold;\">Not Compatible Format.Please Upload Only Image File.</p>";
								  }
								  
								  
								  else
								  {
									move_uploaded_file($_FILES['file']['tmp_name'],"../image/".$_FILES['file']['name']);  
								   include('dbcon.php');
							        $sql="UPDATE tblbuyer SET photo='$path' where username='$un';";
                                   if(mysqli_query($con,$sql))
								  {
									  echo"<h4 style=\"color:green; text-align:center;\">Record Update Successfully!</h4>";
									  header("Location: editaccount.php");
                            	 }								  
								  else
								  {
									  echo"<h4 style=\"color:red; text-align:center;\">Error</h4>";
								  }
								  }
								  
							   }
					  }
						 ?>
					 <!-- phtoupdate code End-->
					 
					 <!-- Edit code start-->
					 <?php
					  if (isset($_POST['btnupdate']))
                      {
						  $un=$_SESSION['buyer'];
						  $name=$_POST['fullname'];
						  $mobile=$_POST['mobileno'];
						  $add=$_POST['address'];
						  $pin=$_POST['pincode'];
							
						  if(empty($name))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Full Name</p>";
						  }
						  else if(empty($mobile))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Mobile No</p>";
						  }
						  else if(empty($add))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Address</p>";
						  }
						  else if(empty($pin))
						  {
							  echo"<p style=\"color:red; text-align:center; \">Please Enter Pincode</p>";
						  }
						  else
						  {
							  include('dbcon.php');
							  
							  $sql="UPDATE tblbuyer SET fullname='$name',mobileno='$mobile', address='$add', pincode='$pin';";
                              if(mysqli_query($con,$sql))
                              {
								  echo"<h4 style=\"color:green; text-align:center;\">Record Update Successfully!</h4>";
								  
								  header("Location:myaccount.php");
								  echo'<script>clearinputs();</script>';
							  }								  
							  else
							  {
								  echo"<h4 style=\"color:red; text-align:center;\">Error</h4>";
							  }
						 }
					  }						  
					 ?>
					  <!-- Edit code End-->
					  <form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
			<?php
					    include('dbcon.php');
						$un=$_SESSION['buyer'];
	                    $sql="SELECT * FROM tblbuyer where username='$un'";
						$result=mysqli_query($con,$sql);
						echo"<div class=\"row\">";
                        while($line=mysqli_fetch_array($result))
                        {	
							$id=$line['itemid'];
							$name=$line['fullname'];
							$photo=$line['photo'];
							$mobile=$line['mobileno'];
							$add=$line['address'];
							$pin=$line['pincode'];
							
							
							echo "<div class=\"col-md-4\">";
			                echo "<img src=\"$photo\" style=\"width:200px;height:200px;border-radius:50%;margin:30px\"class=\"p\"  />";
							echo "<div class=\"ph\"> Change Photo :  <input type=\"file\" name=\"file\" id=\"file\" class=\"file\" value=\"\">";
							echo "<input type=\"submit\" name=\"photoupdate\" id=\"phbtn\" value=\"Update\"   class=\"btn btn-success photoupdate\">";
							echo "</div>";
							echo "</div>";
							echo "<div class=\"col-md-8\" style=\"margin-top:30px\">";
							
							echo"<tr><td>Full Name</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"name\" name=\"fullname\" class=\"form-control\" value=\"$name\" />";
							echo"</td>";
							echo"</tr>";
							
							
							
							echo"<tr><td>Mobile Number</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"name\" name=\"mobileno\" class=\"form-control\" value=\"$mobile\" />";
							echo"</td>";
							echo"</tr>";
							
							echo"<tr><td>Address</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"name\" name=\"address\" class=\"form-control\" value=\"$add\" />";
							echo"</td>";
							echo"</tr>";
							
							echo"<tr><td>Pincode</td>";
							echo"<td>";
							echo"<input type=\"text\" id=\"name\" name=\"pincode\" class=\"form-control\" value=\"$pin\" />";
							echo"</td>";
							echo"</tr>";
							
							echo"<td>";
							echo"<input type=\"submit\" id=\"btnupdate\" name=\"btnupdate\" value=\"Update\" class=\"btn btn-success\"/>";
							echo"</td>";
							echo"</tr>";
							
							echo "</div>";
						}
                        echo"</div>";
                       ?>
			</div>
		</div>
	</div>

</html>