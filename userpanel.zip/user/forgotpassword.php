<?php
	ob_start();
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
	.col-md-3
	{
		
		width:300px;
	}
	.col-md-6
	{
		background-color:white;
		width:480px;
		height:520px;
		margin-left:100px;
		margin-right:100px;
		border-style: ridge;
	}
	.head
	{
		margin:30px;
	}
	.f1
	{
		margin:30px;
		font-family:calibri;
		font-size:17;
		color:black;
		margin-top:20px;
	}
	.f2
	{
		margin-left:30px;
	}
	#txtmobile
	{
		width:400px;
		height:50px;
		
	}
	#txtuname
	{
		width:400px;
		height:50px;
		
	}
	#btnsubmit
	{
		background-color: #DD2745; 
		  border: none;
		  color: white;
		  width:400px;
			height:50px;
		  padding: 10px 32px;
		  text-align: center;
		  text-decoration: none;
		  display: inline-block;
		  font-size: 16px;
	}
	.fpass
	{
		margin-left:300px
	}
  </style>
  <script>
			function funlogin()
				{
					if (txtname.value=="")
					{
						alert("Please enter your Username");
						txtname.style.border='2px solid black';
						
						txtname.focus();
					}
					else if (password.value=="")
					{
						alert("Please enter your Password");
						password.style.border='2px solid black';
						password.focus();
					}
					else
					{
						return true;
					}
					return false;
				}
		</script>
  </head>
  <body style="background:url('images/login.jpg');">
 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
		<div class="form">
		<?php
			if (isset ($_POST['btnsubmit']))
			{
				if (empty ($_POST ['txtmobile']))
				{
					echo "<h3 style=\"color:red;\">Please Enter your Mobile Number</h3>";
				}
				else if (empty ($_POST ['txtuname']))
				{
					echo "<h3 style=\"color:red;\">Please Enter your Username</h3>";
				}
				else
				{
					$un=$_POST['txtuname'];
					$mobile=$_POST['txtmobile'];
					$sql="select * from tblbuyer where username='$un' and mobileno='$mobile' and status=1";
					include('dbcon.php');
					$result=mysqli_query($con,$sql);
					$count=mysqli_num_rows($result);
					 if($count==1)
					{
						while($line=mysqli_fetch_array($result))
						{
							echo "<h3 style=\"color:green\">Your password is ";
							echo $line['password'];
							echo "</h3>";
						}
						
					}
					else
					{
						echo "<h3 style=\"color:red;\">Invalid Username or Mobile Number</h3>";
					}
				}
			}
		?>
		
		<div class="row">
		<div class="col-md-12" style="color:#CD223E;text-align:center;font-size:35px;font-family:calibri;font-weight:bold">
			e-gift
        </div>
		 </div>
		 <div class="row">
		<div class="col-md-3">
			
        </div>
		
		<div class="col-md-6">
		<form id="form1" name="form1" method="POST" action="">
			<div class="head">
			<h2 style="font-family:Georgia;font-weight:bold">Reset your password</h2>
			</div>
			<div class="head2">
					<div class="f1">Enter Mobile Number<br><input type="text" id="txtmobile" name="txtmobile" value="" placeholder="Enter Mobile Number"/></div>
				</div>
				<div class="head2">
					<div class="f1">Enter Username<br><input type="text" id="txtuname" name="txtuname" value="" placeholder="Enter Username"/></div>
				</div>
				<div class="head2">
					<div><input class="f2" type="submit" id="btnsubmit" name="btnsubmit" value="SEND DATA" onclick="return funlogin();" /></div>
				</div>
				</form>
        </div>
		<div class="col-md-3">
			
        </div>
		 </div>
  </body>
</html>







		
		