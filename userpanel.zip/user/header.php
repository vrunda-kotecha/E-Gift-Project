<?php
	ob_start();
	session_start();
?>

<html>
<head>
  <!-- Basic -->
 
  <title>
    E-gift
  </title>
 <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" integrity="sha512-Evv84Mr4kqVGRNSgIGL/F/aIDqQb7xQ2vcrdIwxfjThSH8CSR7PBEakCr51Ck+w+/U6swU2Im1vVX0SVk9ABhg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<style>
		#src
		{
			width:50px;
		}
		.nav-link
		{
			background-color:white;
		}
		.nav-link:hover
		{
			background-color:#F5E3E5;
			color:white;
		}
	</style>
  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  </head>
<body>
<div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <nav class="navbar navbar-expand-lg custom_nav-container ">
        <a class="navbar-brand" href="index.php">
         
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class=""></span>
        </button>

        <div class="collapse navbar-collapse innerpage_navbar" id="navbarSupportedContent">
		<a href="index.php">
		<h2 style="color:#CD223E;margin-right:90px;margin-top:5px;margin-left:20px">
			e-gift
          </h2>
		  </a>
          <ul class="navbar-nav  ">
            <li class="nav-item ">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="shop.php">
                Shop
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="why.php">
                Why Us
              </a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="perfectgift.php">
                Perfect Gift
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="myaccount.php">My Account</a>
            </li>
          </ul>
          <div class="user_option">
		 
            </a>
            <a href="createorder.php">
			<i class="fa-solid fa-cart-shopping" style="color: #CD223E;" aria-hidden="true">
			<span class="position-absolute  start-100 translate-middle badge rounded-circle" style="color:white;background-color:#CD223E">
					<?php
						include('dbcon.php');
						if(!empty($_SESSION['buyer']))
						{		
								$name=$_SESSION['buyer'];
								$sql="select * from tblcart where username='$name' and status=1";
								$result=mysqli_query($con,$sql);
								$count=mysqli_num_rows($result);
								echo $count;
						}
						else
						{
							//header("Location: login.php");
						}
					?>
				
				</span></i></a>
              <a href="searchgifts.php" class="btn nav_search-btn"   style="margin-right:170px;margin-left:15px;color:#CD223E;margin-top:5px">
			  
                <i class="fa fa-search" aria-hidden="true"></i>
              </a>
			 
			<?php
								if(!isset($_SESSION['buyer']))
								{
									echo " <a href=\"login.php\"><i class=\"fa fa-user\" aria-hidden=\"true\"></i>Login</a>";
								}
								else
								{
									echo " <a href=\"logout.php\"><i class=\"fa fa-user\" aria-hidden=\"true\"></i>Logout</a>";
								}
                		
							
			 ?>
          </div>
        </div>
      </nav>
    </header>
	
    <!-- end header section -->