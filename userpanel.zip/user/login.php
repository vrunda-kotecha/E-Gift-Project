<?php
    ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <title>Login Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <style>
        body {
            background: url('images/login.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .login-card {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            border: 1px solid #dee2e6;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            margin: auto;
        }
        .login-title {
            font-family: Georgia, serif;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        .login-subtitle {
            color: #636363;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-control {
            height: 50px;
        }
        #btnsubmit {
            background-color: #DD2745;
            border: none;
            color: white;
            width: 100%;
            height: 50px;
            font-size: 16px;
        }
        .forgot-pass {
            text-align: right;
            margin-top: 10px;
        }
        .forgot-pass a {
            color: #636363;
            text-decoration: none;
        }
    </style>
    <script>
        function funlogin() {
            if (document.getElementById('txtname').value == "") {
                alert("Please enter your Username");
                document.getElementById('txtname').style.border = '2px solid black';
                document.getElementById('txtname').focus();
                return false;
            } else if (document.getElementById('password').value == "") {
                alert("Please enter your Password");
                document.getElementById('password').style.border = '2px solid black';
                document.getElementById('password').focus();
                return false;
            }
            return true;
        }
    </script>
</head>
<body>

<div class="container py-5">
    <div class="text-center mb-4" style="color:#CD223E; font-size: 35px; font-family: Calibri; font-weight: bold;">
        e-gift
    </div>
    
    <div class="login-card">
        <?php
            if (isset($_POST['btnsubmit'])) {
                if (empty($_POST['txtname'])) {
                    echo "<h5 class='text-danger text-center'>Please Enter your Username</h5>";
                } else if (empty($_POST['password'])) {
                    echo "<h5 class='text-danger text-center'>Please Enter your Password</h5>";
                } else {
                    $un = $_POST['txtname'];
                    $pwd = $_POST['password'];
                    $sql = "SELECT * FROM tblbuyer WHERE username='$un' AND password='$pwd' AND status=1";
                    include('dbcon.php');
                    $result = mysqli_query($con, $sql);
                    $count = mysqli_num_rows($result);
                    if ($count == 1) {
                        session_start();
                        $_SESSION['buyer'] = $un;
                        header('location:index.php');
                    } else {
                        echo "<h5 class='text-danger text-center'>Invalid Username and Password</h5>";
                    }
                }
            }
        ?>

        <form method="POST" onsubmit="return funlogin();">
            <div class="login-title">
                Sign In
            </div>
            <div class="login-subtitle">
                Don't have an account? <a href="registration.php">Sign Up</a>
            </div>
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" id="txtname" name="txtname" class="form-control" placeholder="Enter your username">
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password">
            </div>
            <div class="d-grid">
                <input type="submit" id="btnsubmit" name="btnsubmit" value="SIGN IN" class="btn">
            </div>
           
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>