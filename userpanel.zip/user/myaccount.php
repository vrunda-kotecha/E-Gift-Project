<?php
    ob_start();
?>
<html>
	<head>
		<style>
			.box
			{
				background-color:#F5E3E5;
				margin-top:20px;
				height:350px;
			}
			.box1
			{
				background-color:#F5E3E5;
				margin-top:20px;
				
			}
			.content
			{
				margin-left:20px;
				margin-right:20px
				
			}
			
		</style>
	</head>
<?php
			include ('header.php');
?>

<?php
	if(!isset($_SESSION['buyer']))
	{
		header("Location:login.php");
	}
?>

    <div class="row">  
		<div class="col-md-3">
			<div class="box">
				<div class="content">
				<a href="myaccount.php" style="color:black">
					<hr>
						My profile
				</a>
					<br>
					<hr>
				<a href="editaccount.php" style="color:black">
						Edit Profile
				</a>
					<br>
					<hr>
				<a href="changepassword.php" style="color:black">
						Change Password
				</a>
					<br>
					<hr>
				<a href="orderhistory.php" style="color:black">
						Order History
				</a>
					<hr>
					<a href="index.php" style="color:black">
						Back to Home
				</a>
				<br>
					<hr>
				<a href="shop.php" style="color:black">
						Browse Gifts
				</a>
				</div>
			</div>
		</div>
		<div class="col-md-9">
			<div class="box1">
			<form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">

			<?php
					    include('dbcon.php');
						$un=$_SESSION['buyer'];
	                    $sql="SELECT * FROM tblbuyer where username='$un'";
						$result=mysqli_query($con,$sql);
						echo"<div class=\"row\">";
                        while($line=mysqli_fetch_array($result))
                        {	$id=$line['itemid'];
							$name=$line['fullname'];
							$photo=$line['photo'];
							$username=$line['username'];
							$mobile=$line['mobileno'];
							$add=$line['address'];
							$pin=$line['pincode'];
							$regdate=$line['cdate'];
							
							echo"<div class=\"col-md-4\">";
			                echo "<img src=\"$photo\" style=\"width:200px;height:200px;border-radius:50%;margin:30px\"class=\"p\"  />";
							echo"</div>";
							echo "<div class=\"col-md-8\" style=\"margin-top:30px\">";
							echo "<div>";
                            echo"<h2 style=\"font-family:Georgia\">";
			                echo $line['fullname'];
							echo"</h2>";
							echo "<a href=\"editaccount.php\">edit</a>";
							echo "</div>";
							echo "<hr>";
							echo "<br>";
							echo "<i class=\"fa-regular fa-circle-user\" style=\"margin-right:10px;margin-bottom:20px\"></i>";
			                echo $line['username'];
							echo "<br>";
							echo "<i class=\"fa-solid fa-phone\" style=\"margin-right:10px;margin-bottom:20px\"></i>";
			                echo $line['mobileno'];
							echo "<br>";
							echo "<i class=\"fa-solid fa-location-dot\" style=\"margin-right:10px;margin-bottom:20px\"></i>";
							echo $line['address'];
							echo ",";
							echo $line['pincode'];
						}
                        echo"</div>";
                       ?>
			</div>
		</div>
	</div>

</html>