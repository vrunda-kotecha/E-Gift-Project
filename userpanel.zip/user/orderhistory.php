<?php
    ob_start();
?>
<html>
	<head>
		<style>
			.box
			{
				background-color:#F5E3E5;
				margin-top:20px;
				height:350px;
			}
			.box1
			{
				background-color:#F5E3E5;
				margin-top:20px;
				
			}
			.content
			{
				margin-left:20px;
				margin-right:20px
				
			}
			
		</style>
	</head>
<?php
			include ('header.php');
?>

<?php
	if(!isset($_SESSION['buyer']))
	{
		header("Location:login.php");
	}
?>

    <div class="row">  
		<div class="col-md-3">
			<div class="box">
				<div class="content">
				<a href="myaccount.php" style="color:black">
					<hr>
						My profile
				</a>
					<br>
					<hr>
				<a href="editaccount.php" style="color:black">
						Edit Profile
				</a>
					<br>
					<hr>
				<a href="changepassword.php" style="color:black">
						Change Password
				</a>
					<br>
					<hr>
				<a href="orderhistory.php" style="color:black">
						Order History
				</a>
					<hr>
					<a href="index.php" style="color:black">
						Back to Home
				</a>
				<br>
					<hr>
				<a href="shop.php" style="color:black">
						Browse Gifts
				</a>
				</div>
			</div>
		</div>
		<div class="col-md-9">
			<div class="box1">
			<form enctype="multipart/form-data" class="forms-sample" id="form" name="form" method="POST" action="">
			<div class="panel-body">
			<h2 style="font-family:Georgia;font-weight:bold;text-align:center;background-color:white">Order History</h2>
                            <?php
                                
                                include('dbcon.php');
                                $name=$_SESSION['buyer'];
								$sql="SELECT `tblorder`.`orderid` as `pid`,`tblgift`.`giftphoto` as `pphoto`,`tblgift`.`description` as `pname`,`tblgift`.`price` as `pprice`,`tblgift`.`quantity` as `pquantity`,`tblbuyer`.`mobileno` as `umobileno`,tblorder.cdate as cdate  FROM  `tblbuyer` inner join `tblgift` inner join `tblorder`   where `tblorder`.`username`=`tblbuyer`.`username` and `tblorder`.`productid`=`tblgift`.`gid` and `tblbuyer`.`username`='$name' order by orderid desc";
                                
                                $result=mysqli_query($con,$sql);
                                $count=mysqli_num_rows($result);
                                if($count==0)
                                {
                                    echo "<h4 style=\"color:red\">No Record Found</h4>";
                                }
                                else
                                {
                                    echo "<table class=\"table\">
                                            <tr>
                                                <th>ORDER NO.</th>
                                                <th>PHOTO</th>
                                                <th>NAME</th>
                                                <th>PRICE</th>
                                                <th>QUANTITY</th>
                                                <th>MOBILE</th>
                                                <th>ORDER DATE</th>
                                            </tr>";
                                     
                                    while($line=mysqli_fetch_array($result))
                                    {
                                        echo "<tr>";
                                        echo "<td>";
                                        echo $line['pid'];
                                        echo "</td>";
                                        echo "<td><img style=\"height:200px;width:250px;\" src=\"";
                                        echo $line['pphoto'];
                                        echo "\" /></td>";
                                        echo "<td>";
                                        echo $line['pname'];
                                        echo "</td>";
                                        echo "<td>";
                                        echo $line['pprice'];
                                        echo "</td>";
                                        echo "<td>";
                                        echo $line['pquantity'];
                                        echo "</td>";
                                        echo "<td>";
                                        echo $line['umobileno'];
                                        echo "</td>";
                                        echo "<td>";
                                        echo $line['cdate'];
                                        echo "</td>";
                                        echo "</tr>";
                                    }
                                    echo "</table>";
                                }
                            ?>
                        </div>
			
			</div>
		</div>
	</div>

</html>