 
  <?php
			include ('header.php');
	?>
 <section class="saving_section ">
    <div class="box" style="background-color:#F5E3E5;height:370px;width:1100px;margin-top:50px;">
      <div class="container-fluid" >
        <div class="row">
          <div class="col-lg-6" >
            <div class="img-box" style="height:250px;width:300px;">
              <img src="images/favicon2.png" alt="" >
            </div>
          </div>
          <div class="col-lg-6" >
            <div class="detail-box" >
              <div class="heading_container" style="color:#DA2744">
                <h2>
                  Find The Perfect Gift
                </h2>
              </div>
              <p style="color:#DA2744">
				Discover Gifts by Recipient, Relationships & Occasions</p>
             <h2 style="color:#DA2744;margin-top:30px">Lets Go!!</h2>
          </div>
        </div>
      </div>
    </div>
  </section>
		<div>
			<h1 style="font-family:geogia;margin-top:50px;margin-left:30px">
			Choose Recepient:
			</h1>
				<div class="row">
					<div class="col-md-4">
						<a href="viewrecepient.php?id=1"><img src="images/men1.jpg"/></a>
						<br><h5 style="margin-left:120px">Men</h5>
					</div>
					<div class="col-md-4">
						<a href="viewrecepient.php?id=2"><img src="images/women1.jpg"/></a>
						<h5 style="margin-left:120px">Women</h5>
					</div>
					<div class="col-md-4">
						<a href="viewrecepient.php?id=4"><img src="images/cou1.jpg"/></a>
						<h5 style="margin-left:130px;margin-top:5px">Couples</h5>
					</div>
				</div>
		</div>
		<div>
			<h1 style="font-family:geogia;margin-top:50px;margin-left:30px">
			Select Occasions:
			</h1>
			<div class="row">
					<div class="col-md-4">
						<a href="viewrecepient.php?id=5"><img src="images/birthdayes.jpg"/></a>
						<h5 style="margin-left:80px;margin-top:15px">Birthday</h5>
					</div>
					<div class="col-md-4">
						<a href="viewrecepient.php?id=6"><img src="images/anniversaryrec.jpg"/></a>
						<h5 style="margin-left:80px;margin-top:5px">Anniversary</h5>
					</div>
					<div class="col-md-4">
						<a href="view.php?id=3"><img src="images/bestwishes.jpg"/></a>
						<h5 style="margin-left:130px;margin-top:15px">Bestwishes</h5>
					</div>
				</div>
		</div>
   <?php
	include ('footer.php');
	?>
	
	
	