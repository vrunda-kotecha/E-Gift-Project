<?php
	ob_start();
?>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <title>Registration Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
	.col-md-3
	{
		
		width:300px;
	}
	.col-md-6
	{
		background-color:white;
		width:480px;
		height:520px;
		margin-left:100px;
		margin-right:100px;
		border-style: ridge;
	}
	.head
	{
		margin:30px;
	}
	.f1
	{
		margin-left:30px;
		font-family:calibri;
		font-size:17;
		color:black;	
		margin-bottom:20px;
	}
	.f3
	{
		font-family:calibri;
		font-size:17;
		color:black;
	}
	.f2
	{
		margin-left:30px;
	}
	#txttitle
	{
		width:70px;
		height:50px;
	}
	#txtname
	{
		width:330px;
		height:50px;
	}
	#txtemail
	{
		width:268px;
		height:50px;
	}
	#password
	{
		width:130px;
		height:50px;
	}
	#txtmobile
	{
		width:268px;
		height:50px;
	}
	#txtdate
	{
		width:130px;
		height:50px;
	}
	#btnsubmit
	{
		background-color: #DD2745; 
		  border: none;
		  color: white;
		  width:400px;
			height:50px;
		  padding: 10px 32px;
		  text-align: center;
		  text-decoration: none;
		  display: inline-block;
		  font-size: 16px;
	}
	.fpass
	{
		margin-left:300px
	}
  </style>
  <script>
			function funlogin()
				{
					if (txttitle.value=="")
					{
						alert("Please enter your Title");
						txttitle.style.border='2px solid black';
						
						txtname.style.backgroundColor='white';
						txtname.style.border='1px solid grey';
						txtemail.style.backgroundColor='white';
						txtemail.style.border='1px solid grey';
						password.style.backgroundColor='white';
						password.style.border='1px solid grey';
						txtmobile.style.backgroundColor='white';
						txtmobile.style.border='1px solid grey';
						txtdate.style.backgroundColor='white';
						txtdate.style.border='1px solid grey';
					
						txttitle.focus();
					}
					else if (txtname.value=="")
					{
						alert("Please enter your Name");
						txtname.style.border='2px solid black';
						
						txttitle.style.backgroundColor='white';
						txttitle.style.border='1px solid grey';
						txtemail.style.backgroundColor='white';
						txtemail.style.border='1px solid grey';
						password.style.backgroundColor='white';
						password.style.border='1px solid grey';
						txtmobile.style.backgroundColor='white';
						txtmobile.style.border='1px solid grey';
						txtdate.style.backgroundColor='white';
						txtdate.style.border='1px solid grey';
						
						txtname.focus();
					}
					else if (txtemail.value=="")
					{
						alert("Please enter your Email");
						txtemail.style.border='2px solid black';
						
						txttitle.style.backgroundColor='white';
						txttitle.style.border='1px solid grey';
						txtname.style.backgroundColor='white';
						txtname.style.border='1px solid grey';
						password.style.backgroundColor='white';
						password.style.border='1px solid grey';
						txtmobile.style.backgroundColor='white';
						txtmobile.style.border='1px solid grey';
						txtdate.style.backgroundColor='white';
						txtdate.style.border='1px solid grey';
						
						txtemail.focus();
					}
					else if (password.value=="")
					{
						alert("Please enter your Password");
						password.style.border='2px solid black';
						
						txttitle.style.backgroundColor='white';
						txttitle.style.border='1px solid grey';
						txtname.style.backgroundColor='white';
						txtname.style.border='1px solid grey';
						txtemail.style.backgroundColor='white';
						txtemail.style.border='1px solid grey';
						txtmobile.style.backgroundColor='white';
						txtmobile.style.border='1px solid grey';
						txtdate.style.backgroundColor='white';
						txtdate.style.border='1px solid grey';
						
						password.focus();
					}
					else if (txtmobile.value=="")
					{
						alert("Please enter your Mobile Number");
						txtmobile.style.border='2px solid black';
						
						txttitle.style.backgroundColor='white';
						txttitle.style.border='1px solid grey';
						txtname.style.backgroundColor='white';
						txtname.style.border='1px solid grey';
						txtemail.style.backgroundColor='white';
						txtemail.style.border='1px solid grey';
						password.style.backgroundColor='white';
						password.style.border='1px solid grey';
						txtdate.style.backgroundColor='white';
						txtdate.style.border='1px solid grey';
						
						txtmobile.focus();
					}
					else if (txtdate.value=="")
					{
						alert("Please enter your Date of Birth");
						txtdate.style.border='2px solid black';
						
						txttitle.style.backgroundColor='white';
						txttitle.style.border='1px solid grey';
						txtname.style.backgroundColor='white';
						txtname.style.border='1px solid grey';
						txtemail.style.backgroundColor='white';
						txtemail.style.border='1px solid grey';
						password.style.backgroundColor='white';
						password.style.border='1px solid grey';
						txtmobile.style.backgroundColor='white';
						txtmobile.style.border='1px solid grey';
						
						txtdate.focus();
					}
					else
					{
						return true;
					}
					return false;
				}
		</script>
  </head>
  <body style="background:url('images/login.jpg');">
 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
		<div class="form">
		<?php
									if (isset ($_POST['btnsubmit']))
									{
										if (empty ($_POST ['txttitle']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Title</h3>";
										}
										else if (empty($_POST ['txtname']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Name</h3>";
										}
										else if (empty ($_POST ['txtemail']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Email</h3>";
										}
										else if (empty($_POST['password']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Password</h3>";
										}
										else if (empty($_POST['txtmobile']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Mobile Number</h3>";
										}
										else if (empty($_POST['txtdate']))
										{
											echo "<h3 style=\"color:red;\">Please Enter your Date of Birth</h3>";
										}
										else
										{
											$t=$_POST['txttitle']; 
											$n=$_POST['txtname'];
											$eml=$_POST['txtemail'];
											$pass=$_POST['password'];
											$mo=$_POST['txtmobile'];
											$bd=$_POST['txtdate'];
											$s=0;
											$d='2024-11-27 16:37:07';
											
											include ('dbcon.php');
											
											$sql="insert into tblbuyer values(NULL,'$t','$n','$eml','$pass','$mo','$bd','$s','$d')";
											if (mysqli_query($con,$sql))
											{
												echo "<h3 style=\"color:green;\">New User Registered</h3>";
											}
											else
											{
												echo "<h3 style=\"color:red;\">ERROR</h3>";
											}
										}
									}
								?>
		<div class="row">
		<div class="col-md-12" style="color:#CD223E;text-align:center;font-size:35px;font-family:calibri;font-weight:bold">
			e-gift
        </div>
		 </div>
		 <div class="row">
		<div class="col-md-3">
			
        </div>
		
		<div class="col-md-6">
		<form id="form1" name="form1" method="POST" action="">
			<div class="head">
			<h2 style="font-family:Georgia;font-weight:bold">Sign Up</h2>
			<h6 style="color:#636363;">Alreday have an account?<a href="login.php" style="text-decoration:none;margin-left:8px">Sign In</a></h6>
			</div>
			<div class="head2">
			<div class="row">
					<div class="col-md-2 f1">Title <br><input type="text" id="txttitle" name="txttitle" value="<?php if(isset($_POST['txttitle'])) echo $_POST['txttitle']; ?>" placeholder="Mr./Ms."/></div>
					<div class="col-md-9 f3">Full Name<br><input type="text" id="txtname" name="txtname" value="<?php if(isset($_POST['txtname'])) echo $_POST['txtname']; ?>" placeholder="Name"/></div>					
			</div>
			</div>
			<div class="head2">
			<div class="row">
					<div class="col-md-7 f1">Email ID <br><input type="text" id="txtemail" name="txtemail" value="<?php if(isset($_POST['txtemail'])) echo $_POST['txtemail']; ?>" placeholder="Email ID"/></div>
					<div class="col-md-4 f3">Password<br><input type="password" id="password" name="password" value="<?php if(isset($_POST['password'])) echo $_POST['password']; ?>" placeholder="Atleast 6 characters"/></div>					
			</div>
			</div>
			<div class="head2">
			<div class="row">
					<div class="col-md-7 f1">Mobile Number<br><input type="text" id="txtmobile" name="txtmobile" value="<?php if(isset($_POST['txtmobile'])) echo $_POST['txtmobile']; ?>" placeholder="Mobile No."/></div>
					<div class="col-md-4 f3">Date of Birth<br><input type="date" id="txtdate" name="txtdate" value="<?php if(isset($_POST['txtdate'])) echo $_POST['txtdate']; ?>" placeholder="Date of Birth"/></div>					
			</div>
			</div>
				<div class="head2">
					<div><input class="f2" type="submit" id="btnsubmit" name="btnsubmit" value="SIGN IN" onclick="return funlogin();" /></div>
				</div>
				</form>
        </div>
		<div class="col-md-3">
			
        </div>
		 </div>
  </body>
</html>







		
		