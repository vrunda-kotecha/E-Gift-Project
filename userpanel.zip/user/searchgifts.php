<?php
	ob_start();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<style>
	#btnsubmit
	{
		background-color:#CD223E; 
		  border:none;
		  color: white;
		  width:120px;
			height:50px;
		  padding: 8px 32px;
		  text-align: center;
		  text-decoration: none;
		  display: inline-block;
		  font-size: 16px;
		   border-radius: 25px;
		   margin-left:500px;
	}
	#txtsearch
	{
		width:820px;
		height:50px;
		margin-left:160px;
		border-radius: 25px;
  border: 2px solid #CD223E;
  padding: 20px; 
  
	}
	</style>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Search Gifts</title>
		<?php
			include ('header.php');
		?>
		
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
					<center>
                        <h3 class="page-head-line" style="margin-top:20px;color:#CD223E">Seach For Gifts</h3>
                        </center>
							<div class="panel-heading">
							<form id="form1" name="form1" method="POST" action="">
			<div class="form-group">
				<input id="txtsearch" name="txtsearch" class="form-control" placeholder="Enter Seach term" type="text" value="<?php if(isset($_POST['txtsearch'])) echo $_POST['txtsearch']; ?>"/>
			</div>
				<input id="btnsubmit" name="btnsubmit" type="submit" class="btn" value="SEARCH"/>
		</form>
							</div>
							<div class="panel-body">
								<?php
								$sql="select * from tblgift";
			if(isset ($_POST ['btnsubmit']))
			{
				$s=$_POST ['txtsearch'];
				$s="%".$s."%";
				$sql="select * from tblgift where description like '$s'";
			}
			include('dbcon.php');
			$result=mysqli_query($con,$sql);
			$count=mysqli_num_rows($result);
								
								if ($count==0)
								{
									echo "<h4 style=\"color:red\"> NOTHING SIMILAR FOUND</h4>";
								}
								else 
								{
									echo "<h6 style=\"color:#CD223E\"> TOTAL $count GIFTS FOUND</h6>";
								}
								echo "<table class=\"table\">
									<tr>
										<th>PHOTO</th>
										<th >DESCRIPTION</th>
										<th style=\"width:500px\">PRICE</th>
									</tr>";
									while($line=mysqli_fetch_array($result))
									{
										echo "<tr>";
										echo "</td><td><img style=\"height:200px;width:220px;\" src=\"";
										echo $line['giftphoto'];
										echo "\" /></td><td>";
										echo $line ['description'];
										echo "</td><td>";
										echo $line ['price'];
										echo "</td><td>";
										
									}
									echo "</table>";
							?>
							</div>
						</div>
                </div>
                <!-- /. ROW  -->

            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
		<?php
			include ('footer.php');
		?>
                      
                
                

   
