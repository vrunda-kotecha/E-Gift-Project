<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">

  <title>
    E-gift
  </title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
  .img1
		{
			height:250px;
			width:500px;
		}
		.img2
		{
			height:120px;
			height:250px;
			width:500px;
		}
  </style>
</head>

<body>

    <?php
			include ('header.php');
	?>

  </div>
  <!-- end hero area -->

  <!-- shop section -->

<section class="shop_section ">
    <div class="container">
      <div class="heading_container heading_center">
		
		</div>
		<h2 style="font-family:georgia;margin-left:30px">
          Send Surprises To Your Loved Ones
        </h2>
		<div class="row" style="margin:10px">
			<div class="col-md-5 img1">
			<a href="viewrecepient.php?id=1">
				<img src="images/forhim.jpg"/>
				
			</a>
			<h5 style="margin-left:230px">For him</h5>
			</div>
			<div class="col-md-1">
				
			</div>
			<div class="col-md-5 img2">
			<a href="viewrecepient.php?id=2">
				<img src="images/forher.jpg"/>
				</a>
				<h5 style="margin-left:230px">For her</h5>
			</div>
		</div>
		<center>
		<h1 style="font-family:georgia;font-weight:bold">
         Catagories
        </h1>
		</center>
       <?php
								$sql="SELECT * FROM tblitemcategory";
								include ('dbcon.php');
								$result=mysqli_query($con,$sql);
								$count=mysqli_num_rows($result);
								
								
								echo "<div class=\"row\">";
								$counter=1;
								
									while($line=mysqli_fetch_array($result))
									{
										$id=$line['itemcatid'];
										echo "<div class=\"col-sm-6 col-md-4 col-lg-3\">";
										echo "<div class=\"box\">";
										echo "<div class=\"img-box\">";
										echo "<a href=\"view.php?id=$id\"><img style=\"height:230px;width:240px;\" src=\"";
										echo $line['photo'];
										echo "\" /></a>";
										echo "</div>";
										echo "<div class=\"detail-box\"><h5>";
										echo $line ['categoryname'];
										echo "</h5>";
										echo "</div>";
										echo "</div>";
										echo "</div>";
										if($counter%4==0)
										{
											echo "</div><div class=\"row\">";
										}
										$counter=$counter+1;
									}
									
									echo "</div>";
									
							?>
          
        
      
      <div class="btn-box">
        <a href="viewall.php">
          View All Products
        </a>
      </div>
	  <div>
			<h2 style="font-family:georgia;margin-top:30px">
				Wide range of gifts for your celebration
			</h2>
			<div class="row">
				<div class="col-md-6">
					<div class="card mb-3" style="max-width: 540px;">
					<a href="view.php?id=2" style="text-decoration: none;color:black">
						  <div class="row g-0">
							<div class="col-md-8">
							
							  <img src="images/catcake.jpg" class="img-fluid rounded-start" style="padding:5px" alt="...">
							</div>
							<div class="col-md-4">
							  <h5 style="font-family:georgia;margin-top:10px;margin-bottom:25px">Cakes</h5>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Birthday Cakes</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Chocolate Cakes</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Pinata Cakes</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Truffle Cakes</div>
							</div>
						  </div>
						  </a>
						</div>
				</div>
				<div class="col-md-6">
					<div class="card mb-3" style="max-width: 540px;">
					<a href="view.php?id=1" style="text-decoration: none;color:black">
						  <div class="row g-0">
							
							<div class="col-md-4">
							  <h5 style="font-family:georgia;margin-top:10px;margin-bottom:20px;margin-left:10px">Flowes</h5>
							  <div style="color:#97B1CF;margin-left:10px;font-size:15px;margin-bottom:5px">Anniversary Flowers</div>
							  <div style="color:#97B1CF;margin-left:10px;font-size:15px;margin-bottom:5px">Birthday Flowers</div>
							  <div style="color:#97B1CF;margin-left:10px;font-size:15px;margin-bottom:5px">Roses</div>
							  <div style="color:#97B1CF;margin-left:10px;font-size:15px;margin-bottom:5px">Orchids</div>
							</div>
							<div class="col-md-8">
							  <img src="images/catflower.jpg" class="img-fluid rounded-start" style="padding:5px" alt="...">
							</div>
						  </div>
						  </a>
						</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
				<div class="card mb-3" style="max-width: 540px;">
				<a href="view.php?id=3" style="text-decoration: none;color:black">
						  <div class="row g-0">
							<div class="col-md-7">
							  <img src="images/catwatch.jpg" class="img-fluid rounded-start" style="padding:5px" alt="...">
							</div>
							<div class="col-md-5">
							  <h5 style="font-family:georgia;margin-top:10px;margin-bottom:25px">Watch&More</h5>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Collectables</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Accesories</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Home essentials</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Photo frames</div>
							</div>
						  </div>
						  </a>
						</div>
				</div>
				<div class="col-md-4">
				<div class="card mb-3" style="max-width: 540px;">
				<a href="view.php?id=6" style="text-decoration: none;color:black">
						  <div class="row g-0">
							<div class="col-md-7">
							  <img src="images/cathamper.jpg" class="img-fluid rounded-start" style="padding:5px" alt="...">
							</div>
							<div class="col-md-5">
							  <h5 style="font-family:georgia;margin-top:10px;margin-bottom:25px">Hampers</h5>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Birthday Hamper</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Couple Hampers</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Food Hampers</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Flower Hampers</div>
							</div>
						  </div>
						  </a>
						</div>
				</div>
				<div class="col-md-4">
				<div class="card mb-3" style="max-width: 540px;">
				<a href="view.php?id=5" style="text-decoration: none;color:black">
						  <div class="row g-0">
							<div class="col-md-7">
							  <img src="images/catplant.jpg" class="img-fluid rounded-start" style="padding:5px" alt="...">
							</div>
							<div class="col-md-5">
							  <h5 style="font-family:georgia;margin-top:10px;margin-bottom:25px">Plants</h5>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Indoor Plants</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Succulents</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Purifying Plants</div>
							  <div style="color:#97B1CF;font-size:15px;margin-bottom:5px">Couple Planters</div>
							</div>
						  </div>
						  </a>
						</div>
				</div>
			</div>
		</div>
    </div>
  </section>

  <!-- end shop section -->

 <?php
	include ('footer.php');
	?>