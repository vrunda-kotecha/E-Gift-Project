<?php
	ob_start();
?>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">

  <title>
    E-gift
  </title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
  #btncancel
			{
				width:100px;
				height:30px;
				background-color:#DD2745;
				color:white;
				margin-top:20px;
				border-radius:4px;
				padding:10px;
				padding-left:20px;
				padding-right:20px;
				margin-left:440px
			}
  </style>
</head>

  <?php
			include ('header.php');
	?>
<h3 style="color:green">
							<?php
								if(!isset($_SESSION['buyer']))
								{
									header("Location:login.php");
								}
								
							?>
							</h3>
  <!-- shop section -->
<br>
<section class="shop_section">
    <div class="container" >
      <div class="heading_container heading_center">
       <h2>
	   <?php
		$id=$_GET['id'];
		if ($id==1)
		{
			echo "Flowers";
		}
		else if ($id==2)
		{
			echo "Cakes";
		}
		else if ($id==3)
		{
			echo "Watches";
		}
		else if ($id==4)
		{
			echo "Cards and Addons";
			
		}
		else if ($id==5)
		{
			echo "Plants";
		}
		else if ($id==6)
		{
			echo "Hampers";
		}
		else if ($id==7)
		{
			echo "Jewellery";
		}
		else if ($id==8)
		{
			echo "Chocolates";
		}
		else 
		{
			echo "Surprises for Every Celebration";
		}
		?>
		 </h2>
		 <?php
		$id=$_GET['id'];
		if ($id==1)
		{
			echo "<img src=\"images/flowerimg5.jpg\"";
		}
		else if ($id==2)
		{
			echo "<img src=\"images/cakes.jpg\"";
		}
		else if ($id==3)
		{
			echo "<img src=\"images/watch.jpg\"";
		}
		else if ($id==4)
		{
			
		}
		else if ($id==5)
		{
			echo "<img src=\"images/plant.jpg\"";
		}
		else if ($id==6)
		{
			echo "<img src=\"images/hamper1.jpg\"";
		}
		else if ($id==7)
		{
			echo "<img src=\"images/j.jpg\"";
		}
		else if ($id==8)
		{
			echo "<img src=\"images/chocolate.jpg\"";
		}
		else 
		{
			echo "Surprises for Every Celebration";
		}
		?>
      </div>
	  <h2>
	  <br>
	  <br>
	  <?php
		$id=$_GET['id'];
		if ($id==1)
		{
			echo "Say It With Flowers";
		}
		else if ($id==2)
		{
			echo "Unbox Sweetness";
			echo "<br>";
			echo "A cake a day, makes the day";
		}
		else if ($id==3)
		{
			echo "Gifts that Spark Joy";
		}
		else if ($id==4)
		{
			echo "<h2 style=\"margin-left:430px;margin-bottom:20px;color:#97B1CF;font-family:georgia\">";
			echo "Make it extra Special";
			echo "</h2>";
			echo "<h6>";
			echo "<a href=\"createorder.php\" id=\"btncancel\">";
			echo "CONTINUE WITHOUT ADDONS";							
			echo "</a>";
			echo "</h6>";
		}
		else if ($id==5)
		{
			echo "Beautify your Spaces";
			echo "<br>";
			echo "Plants for your picture-perfect home";
		}
		else if ($id==6)
		{
			echo "Best Selling Gifts";
			echo "<br>";
			echo "Packed with love";
		}
		else if ($id==7)
		{
			echo "Enriching Relationships";
			echo "<br>";
			echo "Through thoughtful Gifts";
		}
		else if ($id==8)
		{
			echo "Sweet Surprises";
		}
		else 
		{
			echo "Surprises for Every Celebration";
		}
		?>
      </h2>
	  <br>

	  
<?php
					    include('dbcon.php');
						$id=$_GET['id'];
	                    $sql="SELECT * FROM tblgift where categoryid='$id' ";
						$result=mysqli_query($con,$sql);
						echo "<div class=\"row\">";
								$counter=1;
									while($line=mysqli_fetch_array($result))
									{				
										$id=$line['gid'];
										echo "<div class=\"card\" style=\"width:17rem;margin:8px\">";
										echo "<a href=\"viewproducts.php?id=$id\"><img style=\"height:230px;width:271px;\" src=\"";
										echo $line['giftphoto'];
										echo "\" /></a>";
										echo "<div class=\"card-body\">";
										echo "<h5 class=\"card-title\" style=\"color:#636363\">";
										echo $line ['description'];
										echo "</h5>";
										echo "<h6 class=\"card-text\" style=\"color:black\">";
										
										echo $line ['price'];
										echo "</i>";
										echo "</h6>";
										echo "</div>";
										echo "</div>";
										if($counter%4==0)
										{
											echo "</div><div class=\"row\">";
										}
										$counter=$counter+1;
									}
									
									echo "</div>";
                       ?>
					   
    </div>
  </section>

  <!-- end shop section -->

  


  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <script src="js/custom.js"></script>

</body>

</html>