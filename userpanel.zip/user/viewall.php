<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">

  <title>
    E-gift
  </title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body>
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <nav class="navbar navbar-expand-lg custom_nav-container ">
        <a class="navbar-brand" href="index.php">
          <h2 style="color:#CD223E">
			e-gift
          </h2>
        </a>
      </nav>
    </header>
  </div>
  <!-- end hero area -->

  <!-- shop section -->
<br>
<section class="shop_section ">
    <div class="container">
      <div class="heading_container heading_center">
	  
       <h2>
		Surprises for Every Celebration
        </h2>
		<img src="images/view.jpg"/>
      </div>
      
<?php
					    include('dbcon.php');
						
	                    $sql="SELECT * FROM tblgift";
						$result=mysqli_query($con,$sql);
						$count=mysqli_num_rows($result);
								
								if ($count==0)
								{
									echo "<h6 style=\"color:red\"> NO GIFTS FOUND</h6>";
								}
								else 
								{
									echo "<h6 style=\"color:black\">Showing results for:</h6>";
									echo "<h1 style=\"color:black;font-family:Georgia;font-weight:bold\">All Gifts</h1><h6 style=\"color:#9796A1\">$count Gifts</h6>";
									
								}
						echo "<div class=\"row\">";
								$counter=1;
									while($line=mysqli_fetch_array($result))
									{		
										$id=$line['gid'];
										echo "<div class=\"card\" style=\"width:17rem;margin:10px\">";										
										echo "<a href=\"viewproducts.php?id=$id\"><img style=\"height:230px;width:271px;\" src=\"";
										echo $line['giftphoto'];
										echo "\" /></a>";
										echo "<div class=\"card-body\">";
										echo "<h5 class=\"card-title\" style=\"color:#636363\">";
										echo $line ['description'];
										echo "</h5>";
										
										echo "<h6 class=\"card-text\" style=\"color:black\">";
										echo $line ['price'];
										echo "</h6>";
										
										echo "</div>";
										echo "</div>";
										if($counter%4==0)
										{
											echo "</div><div class=\"row\">";
										}
										$counter=$counter+1;
									}
									
									echo "</div>";
                       ?>
    </div>
  </section>

  <!-- end shop section -->

  


  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <script src="js/custom.js"></script>

</body>

</html>