<?php ob_start(); ?>
<html>
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
  <title>E-gift</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <link rel="stylesheet" href="css/bootstrap.css" />
  <link href="css/style.css" rel="stylesheet" />
  <link href="css/responsive.css" rel="stylesheet" />

  <style>
    .gift-img {
      max-width: 100%;
      height: auto;
      object-fit: cover;
    }
    h2 {
      font-family: Georgia, serif;
      font-weight: bold;
    }
    h5 {
      font-weight: bold;
      margin-top: 30px;
    }
    .btn1, .btn2 {
      margin-top: 30px;
      width: 100%;
    }
    .form-group {
      margin-top: 20px;
    }
    #btnsubmit2 {
      background-color: white;
      border: 1px solid;
      color: #636363;
      height: 45px;
      font-size: 16px;
    }
    #btnsubmit1 {
      background-color: #DD2745;
      border: none;
      color: white;
      height: 45px;
      font-size: 16px;
    }
  </style>
</head>

<body>
<?php include('header.php'); ?>

<?php
if (!isset($_SESSION['buyer'])) {
  header("Location:login.php");
  exit();
}
?>

<br>

<?php
if (isset($_POST['btnsubmit1'])) {
  $timeZone = new DateTimeZone("Asia/Kolkata");
  $date = new DateTime();
  $date->setTimeZone($timeZone);
  $d = $date->format('y-m-d h:i:s');
  $gid = $_GET['id'];
  $rn = $_POST['txtrname'];
  $dd = $_POST['ddate'];
  $username = $_SESSION['buyer'];
  include('dbcon.php');
  
  $sql = "INSERT INTO tblcart (id, username, productid, recipient, ddate, cdate, status) 
          VALUES (NULL, '$username', '$gid', '$rn', '$dd', '$d', 1)";
  if (mysqli_query($con, $sql)) {
    header("Location:viewproducts.php?id=$gid");
    exit();
  } else {
    echo "<p class='text-danger text-center'>Error inserting record</p>";
  }
}
?>

<div class="container py-4">
  <form id="form1" name="form1" action="" method="POST">
    <div class="row">
      <?php
      include('dbcon.php');
      $id = $_GET['id'];
      $sql = "SELECT * FROM tblgift WHERE gid='$id'";
      $result = mysqli_query($con, $sql);
      while ($line = mysqli_fetch_array($result)) {
      ?>
      <div class="col-12 col-md-5">
        <img class="gift-img mb-4" src="<?php echo $line['giftphoto']; ?>" alt="Gift Image">
      </div>

      <div class="col-12 col-md-7">
        <h2><?php echo $line['description']; ?></h2>
        <h5>₹ <?php echo $line['price']; ?></h5>
        
        <div class="form-group mt-4">
          <h6>Description:</h6>
          <p><?php echo $line['height']; ?> cm x <?php echo $line['width']; ?> cm</p>
        </div>

        <div class="row">
          <div class="col-md-6 form-group">
            <h6>Enter Recipient Name:</h6>
            <input type="text" class="form-control" id="txtrname" name="txtrname" placeholder="Name of recipient" required>
          </div>
          <div class="col-md-6 form-group">
            <h6>Pick the best time to deliver:</h6>
            <input type="date" class="form-control" id="ddate" name="ddate" placeholder="Enter Timeslot and Date" required>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <a class="btn btn-outline-secondary btn1" id="btnsubmit2" href="view.php?id=4">MAKE IT EXTRA SPECIAL</a>
          </div>
          <div class="col-md-6">
            <input type="submit" class="btn btn-danger btn2" id="btnsubmit1" name="btnsubmit1" value="ADD TO CART">
          </div>
        </div>

      </div>
      <?php } ?>
    </div>
  </form>
</div>

<script src="js/jquery-3.4.1.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>