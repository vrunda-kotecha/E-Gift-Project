<?php
	ob_start();
?>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">

  <title>
    E-gift
  </title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

  <?php
			include ('header.php');
	?>
<h3 style="color:green">
							<?php
								if(!isset($_SESSION['buyer']))
								{
									header("Location:login.php");
								}
								
							?>
							</h3>
  <!-- shop section -->
<br>
<section class="shop_section">
    <div class="container" >
      <div class="heading_container heading_center">
      
		 

	  
<?php
					    include('dbcon.php');
						$id=$_GET['id'];
	                    $sql="SELECT * FROM tblgift where brandid='$id' ";
						$result=mysqli_query($con,$sql);
						echo "<div class=\"row\">";
								$counter=1;
									while($line=mysqli_fetch_array($result))
									{				
										$id=$line['gid'];
										echo "<div class=\"card\" style=\"width:17rem;margin:8px\">";
										echo "<a href=\"viewproducts.php?id=$id\"><img style=\"height:230px;width:271px;\" src=\"";
										echo $line['giftphoto'];
										echo "\" /></a>";
										echo "<div class=\"card-body\">";
										echo "<h5 class=\"card-title\" style=\"color:#636363\">";
										echo $line ['description'];
										echo "</h5>";
										echo "<h6 class=\"card-text\" style=\"color:black\">";
										
										echo $line ['price'];
										echo "</i>";
										echo "</h6>";
										echo "</div>";
										echo "</div>";
										if($counter%4==0)
										{
											echo "</div><div class=\"row\">";
										}
										$counter=$counter+1;
									}
									
									echo "</div>";
                       ?>
					   
    </div>
  </section>

  <!-- end shop section -->

  


  <script src="js/jquery-3.4.1.min.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <script src="js/custom.js"></script>

</body>

</html>